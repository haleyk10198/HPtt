typedef int mytype;
const int NV=10005;
const int NE=10005*2;
int he[NV],ecnt;
struct edge
{
    int v,next;
    mytype l;
} E[NE];
void adde(int u,int v,mytype l)
{
    E[++ecnt].v=v;
    E[ecnt].l=l;
    E[ecnt].next=he[u];
    he[u]=ecnt;
}
int par[NV],sub[NV],maxsub[NV],used[NV],tot;
/*---------------according to question--------------*/
int n,k;
int level[NV];
int ans;
int now[NV];

void init(){
    ecnt=0;
    memset(he,-1,sizeof(he));
    mem(used,0);
    tot = n;//init() must be used after input n!
    /*------------------according to question--------------*/
    ans = 0;
}
/*----------------------according to question---------------*/
void getlevel(int u,int p){
    now[++now[0]] = level[u];
    for(int i=he[u];i!=-1;i=E[i].next)
        if(E[i].v!=p && !used[E[i].v])
        {
            level[E[i].v] = level[u] + E[i].l;
            getlevel(E[i].v,u);
        }
}
int getSum(int u,int dis){
    int res = 0;
    now[0] = 0;
    level[u] = dis;
    getlevel(u,-1);
    sort(now+1,now+1+now[0]);
    int l = 1, r = now[0];
    while(l<r)
    {
        if(now[l]+now[r]<=k)
        {
            res += r-l;
            l++;
        } else {
            r--;
        }
    }
    return res;
}
/*-----------------Decomposition Part--------------------------*/
int nn;
void dfs1(int u,int p)
{
    sub[u]=1;
    nn++;
    for (int i=he[u]; i!=-1; i=E[i].next)
        if(E[i].v!=p && !used[E[i].v])
        {
            dfs1(E[i].v,u);
            sub[u]+=sub[E[i].v];
        }
}
int dfs2(int u,int p)
{
    for (int i=he[u]; i!=-1; i=E[i].next)
        if(E[i].v!=p && sub[E[i].v]>nn/2 && !used[E[i].v])
            return dfs2(E[i].v,u);
    return u;
}

void decompose(int root,int p)
{
    nn=0;
    dfs1(root,root);
    int centroid = dfs2(root,root);
    if(p==-1)p=centroid;
    par[centroid]=p;
    /*---------------according to question----------*/
    ans += getSum(centroid,0);

    used[centroid] = 1;
    for (int i=he[centroid]; i!=-1; i=E[i].next)
        if(!used[E[i].v] && E[i].v!=p)
        {
            /*-------------according to question------------*/
            ans -= getSum(E[i].v,E[i].l);

            tot = sub[E[i].v];
            decompose(E[i].v,centroid);
        }
    he[centroid] = -1;
}
/*
init();
decompose(1,-1);
*/