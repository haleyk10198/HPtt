///二分（单调增）
double l=0,r=100,mid;
while(r-l>eps)
{
    mid=(l+r)/2;
    if (f(mid)>0)
        r=mid;
    else
        l=mid;
}

///二分（精确binary_search）如果 a 里没有key，最后落在 key 左边还是右边无法确定，但肯定不会差超过 1 个index,会落在最近两个值之间
//闭区间 [l,r]
int l=0,r=10000,mid;
while(l<=r)
{
    mid=l+r>>1;
    if (a[mid]>key)
        r=mid-1;
    else if (a[mid]<key)
        l=mid+1;
    else
        break;
}
if (a[mid]==key);

///二分（lower_bound） 和下面的upper_bound一样，如果 a 里没有 key，还不如用上面的查找
//闭区间 [l,r]
int l=0,r=10000,mid;
while(l<r)
{
    mid=l+r>>1;
    if (a[mid]>=key)       //a[mid]>=key 可以换成一个bool function, 满足条件就推进，
        r=mid;              //如果bool function里的变量c和mid成反比，就要写成c<=key
    else if (a[mid]<key)
        l=mid+1;
}
if (a[r]==key);
//upper_bound 
//闭区间 [l,r]
int l=0,r=9,mid;
while(l<r)
{
    mid=l+(r-l+1>>1);
    if (a[mid]>key)
        r=mid-1;
    else if (a[mid]<=key)   //如果bool function里的变量c和mid成反比，就要写成c>=key
        l=mid;
}



