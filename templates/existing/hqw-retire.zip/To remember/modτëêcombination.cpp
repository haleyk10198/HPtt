const ll md = 1e9+7;
const int MX = 400111;

ll fac[MX], facinv[MX],inv[MX];
inline ll C(ll x, ll y){
    return fac[x]*facinv[y]%md*facinv[x-y]%md;
}
void ini(){
    fac[0] = 1LL, facinv[0] = 1LL;
    inv[1] = 1LL;
    for(ll i=2;i<=400000;i++) inv[i]=(md-md/i)*inv[md%i]%md;
    for(ll i=1;i<=400000;i++) fac[i] = fac[i-1]*i%md;
    for(ll i=1;i<=400000;i++) facinv[i]=facinv[i-1]*inv[i]%md;
}