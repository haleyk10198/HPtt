#define mem(a,v) memset(a,v,sizeof(a))
#define maxn 1005


int degree[maxn];
vector<int> topological(vector<vector<int>> graph){
    vector<int> result;
    vector<int> error;
    vector<int> s;
    mem(degree,0);
    int n = graph.size();
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
            if(graph[i][j])
                degree[j]++;
    }
    for(int i=0;i<n;i++)
        if(!degree[i])
            s.push_back(i);

    int now;
    while(!s.empty())
    {
        now = s[0];
        s.erase(s.begin());
        result.push_back(now);
        for(int i=0;i<n;i++)
        {
            if(graph[now][i])
            {
                degree[i]--;
                graph[now][i]=0;
                if(!degree[i])
                    s.push_back(i);
            }
        }
    }

    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
            if(graph[i][j])
                return error;
    return result;
}

