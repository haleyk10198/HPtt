//求树上任意两点间的path的gcd
int par[LOGN][MAXN], parg[LOGN][MAXN];
//required: int depth[MAXN], referred as d[MAXN] below;

void buildpar(void){
    // build the base case par[0] from tree search first
    for(int i = 1; i < LOGN; i++)
        for(int j = 0; j < MAXN; j++)
            par[i][j]  = par[i-1][par[i-1][j]];
}

void buildgcd(void){
    /* build the base case parg[0] from the node value first
        for(int i = 0; i < MAXN; i++)
            parg[0][i] = value[i];
        */
    for(int i = 1; i < LOGN; i++)
        for(int j = 0; j < MAXN; j++){
            int g1 = parg[i-1][j]; // gcd of the first half the path
            int ithParent = par[i-1][j];
            int g2 = parg[i-1][ithParent];
            parg[i][j] = __gcd(g1, g2);
            //or in short, parg[i][j] = __gcd(par[i-1][j], par[i-1][par[i-1][j]])
        }
}

// Preprocess completed

int lca(int u, int v){
    /* __FILL_IN_THE_BLANKS__ */
    return LCA;
}

int getG(int u, int v){
    if(d[u] < d[v]) swap(u, v); // u is the lower node.
    int dh = d[u]-d[v];
    int res = -1;
    for(int i = 0; i < MAXN; i++)
        if((1<<i) & dh){
            if(res == -1) res = parg[i][u];
            res = __gcd(res, parg[i][u]);
            u = par[i][u];
        }
    return u;
}