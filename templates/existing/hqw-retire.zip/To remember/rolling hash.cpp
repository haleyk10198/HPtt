const int mod = 1e9+7;
const int base = 257;
ll mod_pow(ll a,ll n){
    ll ret = 1;
    while(n > 0){
        if(n & 1) ret = ret * a % mod;
        a = a * a % mod;
        n >>= 1;

    }return ret;
}
void madd(ll &x,ll y){
    x = (x+y)%mod;
}
void msub(ll &x,ll y){
    x -= y;
    x %= mod;
    if(x<0) x+=mod;
}
ll pw[400010],inv[400010];
void init(){
    pw[0] = inv[0] = 1;
    inv[1] = mod_pow(base,mod-2);
    for(int i=1;i<400010;i++)pw[i] = (pw[i-1]*base)%mod;
    for(int i=2;i<400010;i++)inv[i] = (inv[i-1]*inv[1])%mod;
}