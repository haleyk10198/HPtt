vector<int> mpp[maxn];//0 for n and 1 for q
int dp[maxn][3];
void dfs1(int u, int p){
    int big = 0,bigger = 0;
    for(auto v:mpp[u])
    {
        if(v==p)
            continue;
        dfs1(v,u);
        if(dp[v][0]+1>big)
        {bigger = big;big = dp[v][0]+1;}
        else if(dp[v][0]+1>bigger)
            bigger = dp[v][0]+1;
    }
    dp[u][0] = big;
    dp[u][1] = bigger;
}
void dfs2(int u,int p){
    int tmp;
    for(auto v:mpp[u])
    {
        if(v==p)
            continue;
        if(dp[u][0]==dp[v][0]+1)
            tmp = dp[u][1];
        else
            tmp = dp[u][0];
        dp[v][2] = max(dp[u][2],tmp)+1;
        dfs2(v,u);
    }
}
void findFar(){
    dfs1(1,-1);
    dp[1][2] = 0;
    dfs2(1,-1);
}
//max(dp[i][0],dp[i][2])是一点 i 到树中离它最远点的距离