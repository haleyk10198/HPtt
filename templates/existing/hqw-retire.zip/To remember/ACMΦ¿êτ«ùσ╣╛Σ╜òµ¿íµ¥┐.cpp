// ACM計算幾何模板 HIT_jerrybond (未經驗證)
//pi 是 math.h 中的 M_PI
#define eps 1.0e-8
#define zero(x) (((x)>0?(x):-(x))<eps) //1是零，0是非零
#define _sign(x) ((x)>eps?1:((x)<-eps?2:0)) //1是正，0是0，2是负
struct point { double x, y; };struct line {point a, b; };
// cross product (p1-p0)x(p2-p0)
double xmult(point p1, point p2, point p0) { return (p1.x-p0.x)*(p2.y-p0.y)-(p2.x-p0.x)*(p1.y-p0.y); }
double xmult(double x1, double y1, double x2, double y2, double x0, double y0) { return (x1-x0)*(y2-y0)-(x2-x0)*(y1-y0); }
// dot product (p1-p0).(p2-p0)
double dmult(point p1, point p2, point p0) { return (p1.x-p0.x)*(p2.x-p0.x)+(p1.y-p0.y)*(p2.y-p0.y); }
double dmult(double x1, double y1, double x2, double y2, double x0, double y0) { return (x1-x0)*(x2-x0)+(y1-y0)*(y2-y0); }
// euclidean distance
double edist(point p1, point p2) { return sqrt((p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y)); }
double edist(double x1, double y1, double x2, double y2) { return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)); }
// 判三點是否共線
int dots_inline(point p1, point p2, point p3) { return zero(xmult(p1,p2,p3)); }
// 判點是否在線段上（包括端點）
int dot_online_in(point p, line l) { return zero(xmult(p,l.a,l.b))&&(l.a.x-p.x)*(l.b.x-p.x)<eps&&(l.a.y-p.y)*(l.b.y-p.y)<eps; }
int dot_online_in(point p, point l1, point l2) { return zero(xmult(p,l1,l2))&&(l1.x-p.x)*(l2.x-p.x)<eps&&(l1.y-p.y)*(l2.y-p.y)<eps; }
// 判點是否在線段上（不包括端點）
int dot_online_ex(point p, line l) { return dot_online_in(p,l)&&(!zero(p.x-l.a.x)||!zero(p.y-l.a.y))&&(!zero(p.x-l.b.x)||!zero(p.y-l.b.y)); }
// 判兩點在線段同側(在同侧是1，只要有點在線段上就返回0)
int same_side(point p1, point p2, line l) { return
xmult(l.a,p1,l.b)*xmult(l.a,p2,l.b)>eps; }
int same_side(point p1, point p2, point l1, point l2) { return xmult(l1,p1,l2)*xmult(l1,p2,l2)>eps; }
// 判兩點在線段異側(點在線段上返回0)
int opposite_side(point p1, point p2, line l) { return xmult(l.a,p1,l.b)*xmult(l.a,p2,l.b)<-eps; }
int opposite_side(point p1, point p2, point l1, point l2) { return xmult(l1,p1,l2)*xmult(l1,p2,l2)<-eps; }
// 判斷兩線段是否相交(包括端點和部分重合)
int intersect_in(line u, line v) {
  if(!dots_inline(u.a,u.b,v.a)||!dots_inline(u.a,u.b,v.b))
    return!same_side(u.a,u.b,v)&&!same_side(v.a,v.b,u);
  return dot_online_in(u.a,v)||dot_online_in(u.b,v)||dot_online_in(v.a,u)||dot_online_in(v.b,u);
}
int intersect_in(point u1, point u2, point v1, point v2) {
  if(!dots_inline(u1,u2,v1)||!dots_inline(u1,u2,v2))
    return!same_side(u1,u2,v1,v2)&&!same_side(v1,v2,u1,u2);
  return dot_online_in(u1,v1,v2)||dot_online_in(u2,v1,v2)||dot_online_in(v1,u1,u2)||dot_online_in(v2,u1,u2);
}
// 判斷兩線段是否相交(不包括端點和部分重合)
int intersect_ex(line u, line v) { return opposite_side(u.a,u.b,v)&&opposite_side(v.a,v.b,u); }
int intersect_ex(point u1, point u2, point v1, point v2) { return opposite_side(u1,u2,v1,v2)&&opposite_side(v1,v2,u1,u2); }
// 求兩條直線的交點(注意:先判斷線是否平行)
point intersection(line u, line v) {
  point ret=u.a;
  double t=((u.a.x-v.a.x)*(v.a.y-v.b.y)-(u.a.y-v.a.y)*(v.a.x-v.b.x))/((u.a.x-u.b.x)*(v.a.y-v.b.y)-(u.a.y-u.b.y)*(v.a.x-v.b.x));
  ret.x+=(u.b.x-u.a.x)*t;  ret.y+=(u.b.y-u.a.y)*t;  return ret;
}
point intersection(point u1, point u2, point v1, point v2) {
  point ret=u1;
  double t=((u1.x-v1.x)*(v1.y-v2.y)-(u1.y-v1.y)*(v1.x-v2.x))/((u1.x-u2.x)*(v1.y-v2.y)-(u1.y-u2.y)*(v1.x-v2.x));
  ret.x+=(u2.x-u1.x)*t;  ret.y+=(u2.y-u1.y)*t;  return ret;
}
// 點到直線的最近點
point ptoline(point p, point l1, point l2) {
  point t=p;  t.x+=l1.y-l2.y,t.y+=l2.x-l1.x;  return intersection(p,t,l1,l2);}
// 點到線段的最近點
point ptoseg(point p, point l1, point l2) {
  point t=p;
  t.x+=l1.y-l2.y,t.y+=l2.x-l1.x;
  if(xmult(l1,t,p)*xmult(l2,t,p)>eps)   return edist(p,l1)<edist(p,l2)?l1:l2;
  return intersection(p,t,l1,l2);
}
/* 多邊形 */
// 判定凸多邊形，頂點按順時針或逆時針方向，允許鄰邊共線
int is_convex(int n,point *p) {
  int i,s[3]={1,1,1};
  for(i=0;i<n&&s[1]|s[2];i++) s[_sign(xmult(p[(i+1)%n],p[(i+2)%n],p[i]))]=0;
  return s[1]|s[2];
}
// 判定凸多邊形，頂點按順時針或逆時針方向，不允許鄰邊共線
int is_convex_v2(int n, point *p) {
  int i,s[3]={1,1,1};
  for(i=0;i<n&&s[0]&&s[1]|s[2];i++)
    s[_sign(xmult(p[(i+1)%n],p[(i+2)%n],p[i]))]=0;
  return s[0]&&s[1]|s[2];
}
// 判點在凸多邊形內或多邊形邊上時返回1，嚴格在凸多邊形外返回0
int inside_convex(point q, int n, point *p) {
  int i,s[3]={1,1,1};
  for(i=0;i<n&&s[1]|s[2];i++) s[_sign(xmult(p[(i+1)%n],q,p[i]))]=0;
  return s[1]|s[2];
}
// 判點嚴格在凸多邊形內返回1，在邊上或嚴格在外返回0
int inside_convex_v2(point q, int n, point *p) {
  int i,s[3]={1,1,1};
  for(i=0;i<n&&s[0]&&s[1]|s[2];i++) s[_sign(xmult(p[(i+1)%n],q,p[i]))]=0;
  return s[0]&&s[1]|s[2];
}
// 判定点严格在严格凸多边形内
bool pointInConvex(vector<point>& s,point u){
    int n = s.size();
    if(n<3) return false;
    if(_sign(xmult(s[0],s[1],u))<2||_sign(xmult(s[0],s[n-1],u))!=1) return false;
    int l = 2, r = n-1, mid;
    while(l<r){
        mid = (l+r)>>1;
        if(_sign(xmult(s[0],s[mid],u))==1) r = mid;
        else l = mid + 1;
    }
    if(_sign(xmult(s[r],s[r-1],u))!=1) return false;
    return true;
}
// (判定一条线段是否在一个任意多边形内)
/* 三角形 */
// 求三角形的外心
point circumcenter(point a, point b, point c) {
  line u,v;
  u.a.x=(a.x+b.x)/2;  u.a.y=(a.y+b.y)/2;
  u.b.x=u.a.x-a.y+b.y;  u.b.y=u.a.y+a.x-b.x;
  v.a.x=(a.x+c.x)/2;  v.a.y=(a.y+c.y)/2;
  v.b.x=v.a.x-a.y+c.y;  v.b.y=v.a.y+a.x-c.x;
  return intersection(u,v);
}
// 求三角形内心
point incenter(point a, point b, point c) {
  line u,v;  double m,n;
  u.a=a;
  m=atan2(b.y-a.y,b.x-a.x);  n=atan2(c.y-a.y,c.x-a.x);
  u.b.x=u.a.x+cos((m+n)/2);  u.b.y=u.a.y+sin((m+n)/2);
  v.a=b;
  m=atan2(a.y-b.y,a.x-b.x);  n=atan2(c.y-b.y,c.x-b.x);
  v.b.x=v.a.x+cos((m+n)/2);  v.b.y=v.a.y+sin((m+n)/2);
  return intersection(u,v);
}
// 求三角形垂心
point perpencenter(point a, point b, point c) {
  line u,v;
  u.a=c;  u.b.x=u.a.x-a.y+b.y;  u.b.y=u.a.y+a.x-b.x;
  v.a=b;  v.b.x=v.a.x-a.y+c.y;  v.b.y=v.a.y+a.x-c.x;
  return intersection(u,v);
}
/* 圓 */
// 點到直線的距離
double disptoline(point p, point l1, point l2) { return fabs(xmult(p,l1,l2))/edist(l1,l2); }
// 判定直線是否與圓相交(包括相切)
int intersect_line_circle(point c, double r, point l1, point l2) { return disptoline(c,l1,l2)<r+eps; }
// 判定線段與圓相交(包括相切)
int intersect_seg_circle(point c, double r, point l1, point l2) {
  double t1=edist(c,l1)-r,t2=edist(c,l2)-r;
  point t=c;
  if(t1<eps||t2<eps)  return t1>-eps||t2>-eps;
  t.x+=l1.y-l2.y;  t.y+=l2.x-l1.x;
  return xmult(l1,c,t)*xmult(l2,c,t)<eps&&disptoline(c,l1,l2)-r<eps;
}
// 判圆和圆相交(包括相切)
int intersect_circle_circle(point c1, double r1, point c2, double r2) { return edist(c1,c2)<r1+r2+eps&&edist(c1,c2)>fabs(r1-r2)-eps; }
// 計算圓上到點p最近點(當p為圓心，返回圓心)
point dot_to_circle(point c, double r, point p) {
  point u,v;
  if(edist(p,c)<eps) return p;
  u.x=c.x+r*fabs(c.x-p.x)/edist(c,p);
  u.y=c.y+r*fabs(c.y-p.y)/edist(c,p)*((c.x-p.x)*(c.y-p.y)<0?-1:1);
  v.x=c.x-r*fabs(c.x-p.x)/edist(c,p);
  v.y=c.y-r*fabs(c.y-p.y)/edist(c,p)*((c.x-p.x)*(c.y-p.y)<0?-1:1);
  return edist(u,p)<edist(v,p)?u:v;
}
// 計算直線與圓的交點(假設直線與圓有交點)
// 計算線段與圓的交點可用這函數後判定點是否在線段上
void intersection_line_circle(point c, double r, point l1, point l2, point &p1, point &p2) {
  point p=c;
  double t;
  p.x+=l1.y-l2.y;  p.y+=l2.x-l1.x;  p=intersection(p,c,l1,l2);
  t=sqrt(r*r-edist(p,c)*edist(p,c))/edist(l1,l2);
  p1.x=p.x+(l2.x-l1.x)*t;  p1.y=p.y+(l2.y-l1.y)*t;
  p2.x=p.x-(l2.x-l1.x)*t;  p2.y=p.y-(l2.y-l1.y)*t;
}
// 計算圓與圓的交點(假設圓與圓有交點，圓心不重合)
void intersection_circle_circle(point c1, double r1, point c2, double r2, point &p1, point &p2) {
  point u,v;
  double t;
  t=(1+(r1*r1-r2*r2)/edist(c1,c2)/edist(c1,c2))/2;
  u.x=c1.x+(c2.x-c1.x)*t;  u.y=c1.y+(c2.y-c1.y)*t;
  v.x=u.x+c1.y-c2.y;  v.y=u.y-c1.x+c2.x;
  intersection_line_circle(c1,r1,u,v,p1,p2);
}
/* (球面) */
/* 三維 */
struct point3 { double x, y, z; };
struct line3 { point3 a, b; };
struct plane3 { point3 a, b, c; };
// cross product UxV
point3 xmult(point3 u, point3 v) {
  point3 ret;
  ret.x=u.y*v.z-v.y*u.z;  ret.y=u.z*v.x-u.x*v.z;  ret.z=u.x*v.y-u.y*v.x;
  return ret;
}
// dot product U.V
double dmult(point3 u, point3 v) { return u.x*v.x+u.y*v.y+u.z*v.z; }
// 矢量差 U-V
point3 subt(point3 u, point3 v) {
  point3 ret;  ret.x=u.x-v.x;  ret.y=u.y-v.y;  ret.z=u.z-v.z;  return ret;}
// 取並行法向量
point3 pvec(plane3 s){ return xmult(subt(s.a,s.b),subt(s.b,s.c)); }
point3 pvec(point3 s1, point3 s2, point3 s3) { return xmult(subt(s1,s2),subt(s2,s3)); }
// 兩點距離
double edist(point3 p1, point3 p2) { return sqrt((p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y)+(p1.z-p2.z)*(p1.z-p2.z)); }
// 向量大小
double vlen(point3 p) { return sqrt(p.x*p.x+p.y*p.y+p.z*p.z); }
// 判定三點是否共線
int dots_inline(point3 p1, point3 p2, point3 p3) { return vlen(xmult(subt(p1,p2),subt(p2,p3)))<eps; }
// 判定四點是否共面
int dots_onplane(point3 a, point3 b, point3 c, point3 d) { return zero(dmult(pvec(a,b,c),subt(d,a))); }
// 判定點是否在線段上(包括端點)
int dot_online_in(point3 p, line3 l) { 
  return zero(vlen(xmult(subt(p,l.a),subt(p,l.b))))&&(l.a.x-p.x)*(l.b.x-p.x)<eps&&
    (l.a.y-p.y)*(l.b.y-p.y)<eps&&(l.a.z-p.z)*(l.b.z-p.z)<eps;
}
int dot_online_in(point3 p, point3 l1, point3 l2){
  return zero(vlen(xmult(subt(p,l1),subt(p,l2))))&&(l1.x-p.x)*(l2.x-p.x)<eps&&
    (l1.y-p.y)*(l2.y-p.y)<eps&&(l1.z-p.z)*(l2.z-p.z)<eps;
}
// 判定點是否在線段上(不包括端點)
int dot_online_ex(point3 p, line3 l) {
  return dot_online_in(p,l)&&(!zero(p.x-l.a.x)||!zero(p.y-l.a.y)||!zero(p.z-l.a.z))&&
    (!zero(p.x-l.b.x)||!zero(p.y-l.b.y)||!zero(p.z-l.b.z));
}
int dot_online_ex(point3 p, point3 l1, point3 l2) {
  return dot_online_in(p,l1,l2)&&(!zero(p.x-l1.x)||!zero(p.y-l1.y)||!zero(p.z-l1.z))&&
    (!zero(p.x-l2.x)||!zero(p.y-l2.y)||!zero(p.z-l2.z));
}
// 判定點是否在空間三角形上(包括邊界，三點共線無意義)
int dot_inplane_in(point3 p,plane3 s) {
  return zero(vlen(xmult(subt(s.a,s.b),subt(s.a,s.c)))-vlen(xmult(subt(p,s.a),subt(p,s.b)))-
    vlen(xmult(subt(p,s.b),subt(p,s.c)))-vlen(xmult(subt(p,s.c),subt(p,s.a))));
}
int dot_inplane_in(point3 p, point3 s1, point3 s2, point3 s3) {
  return zero(vlen(xmult(subt(s1,s2),subt(s1,s3)))-vlen(xmult(subt(p,s1),subt(p,s2)))-
    vlen(xmult(subt(p,s2),subt(p,s3)))-vlen(xmult(subt(p,s3),subt(p,s1))));
}
// 判定點是否在空間三角形上(不包括邊界，三點共線無意義)
int dot_inplane_ex(point3 p, plane3 s) {
  return dot_inplane_in(p,s)&&vlen(xmult(subt(p,s.a),subt(p,s.b)))>eps&& vlen(xmult(subt(p,s.b),subt(p,s.c)))>eps&&vlen(xmult(subt(p,s.c),subt(p,s.a)))>eps;
}
int dot_inplane_ex(point3 p, point3 s1, point3 s2, point3 s3) {
  return dot_inplane_in(p,s1,s2,s3)&&vlen(xmult(subt(p,s1),subt(p,s2)))>eps&&
    vlen(xmult(subt(p,s2),subt(p,s3)))>eps&&vlen(xmult(subt(p,s3),subt(p,s1)))>eps;
}
// 判斷兩點是否在線段同側(點在線段上返回0，不共面無意義)
int same_side(point3 p1, point3 p2, line3 l) { return dmult(xmult(subt(l.a,l.b),subt(p1,l.b)),xmult(subt(l.a,l.b),subt(p2,l.b)))>eps; }
int same_side(point3 p1, point3 p2, point3 l1, point3 l2) { return dmult(xmult(subt(l1,l2),subt(p1,l2)),xmult(subt(l1,l2),subt(p2,l2)))>eps; }
// 判斷兩點是否在線段異側(點在線段上返回0，不共面無意義)
int opposite_side(point3 p1, point3 p2, line3 l) { return dmult(xmult(subt(l.a,l.b),subt(p1,l.b)),xmult(subt(l.a,l.b),subt(p2,l.b)))<-eps; }
int opposite_side(point3 p1, point3 p2, point3 l1, point3 l2) { return dmult(xmult(subt(l1,l2),subt(p1,l2)),xmult(subt(l1,l2),subt(p2,l2)))<-eps; }
// 判斷兩點是否在平面同側(點在平面上返回0)
int same_side(point3 p1, point3 p2, plane3 s) { return dmult(pvec(s),subt(p1,s.a))*dmult(pvec(s),subt(p2,s.a))>eps; }
int same_side(point3 p1, point3 p2, point3 s1, point3 s2, point3 s3) { return dmult(pvec(s1,s2,s3),subt(p1,s1))*dmult(pvec(s1,s2,s3),subt(p2,s1))>eps; }
// 判斷兩點是否在平面異側(點在平面上返回0)
int opposite_side(point3 p1, point3 p2, plane3 s) { return dmult(pvec(s),subt(p1,s.a))*dmult(pvec(s),subt(p2,s.a))<-eps; }
int opposite_side(point3 p1, point3 p2, point3 s1, point3 s2, point3 s3) { return dmult(pvec(s1,s2,s3),subt(p1,s1))*dmult(pvec(s1,s2,s3),subt(p2,s1))<-eps; }
// 判斷兩空間直線是否平行
int parallel(line3 u, line3 v) { return vlen(xmult(subt(u.a,u.b),subt(v.a,v.b)))<eps; }
int parallel(point3 u1, point3 u2, point3 v1, point3 v2) { return vlen(xmult(subt(u1,u2),subt(v1,v2)))<eps; }
// 判斷兩平面是否平行
int parallel(plane3 u, plane3 v) { return vlen(xmult(pvec(u),pvec(v)))<eps; }
int parallel(point3 u1, point3 u2, point3 u3, point3 v1, point3 v2, point3 v3) { return vlen(xmult(pvec(u1,u2,u3),pvec(v1,v2,v3)))<eps; }
// 判斷直線是否與平面平行
int parallel(line3 l, plane3 s) { return zero(dmult(subt(l.a,l.b),pvec(s))); }
int parallel(point3 l1, point3 l2, point3 s1, point3 s2, point3 s3) { return zero(dmult(subt(l1,l2),pvec(s1,s2,s3))); }
// 判斷兩直線是否垂直
int perpendicular(line3 u, line3 v) { return zero(dmult(subt(u.a,u.b),subt(v.a,v.b))); }
int perpendicular(point3 u1, point3 u2, point3 v1, point3 v2) { return zero(dmult(subt(u1,u2),subt(v1,v2))); }
// 判斷兩平面是否垂直
int perpendicular(plane3 u, plane3 v) { return zero(dmult(pvec(u),pvec(v))); }
int perpendicular(point3 u1, point3 u2, point3 u3, point3 v1, point3 v2, point3 v3) { return zero(dmult(pvec(u1,u2,u3),pvec(v1,v2,v3))); }
// 判斷兩條空間線段是否相交(包括端點和部分重合)
int intersect_in(line3 u, line3 v) { 
  if(!dots_onplane(u.a,u.b,v.a,v.b)) return 0;
  if(!dots_inline(u.a,u.b,v.a)||!dots_inline(u.a,u.b,v.b)) 
    return!same_side(u.a,u.b,v)&&!same_side(v.a,v.b,u);
  return dot_online_in(u.a,v)||dot_online_in(u.b,v)||dot_online_in(v.a,u)||dot_online_in(v.b,u);
}
int intersect_in(point3 u1, point3 u2, point3 v1, point3 v2) {
  if(!dots_onplane(u1,u2,v1,v2)) return 0;
  if(!dots_inline(u1,u2,v1)||!dots_inline(u1,u2,v2))
    return!same_side(u1,u2,v1,v2)&&!same_side(v1,v2,u1,u2);
  return dot_online_in(u1,v1,v2)||dot_online_in(u2,v1,v2)||dot_online_in(v1,u1,u2)||dot_online_in(v2,u1,u2);
}
// 判斷兩條空間線段是否相交(不包括端點和部分重合)
int intersect_ex(line3 u, line3 v) { return dots_onplane(u.a,u.b,v.a,v.b)&&opposite_side(u.a,u.b,v)&&opposite_side(v.a,v.b,u); }
int intersect_ex(point3 u1, point3 u2, point3 v1, point3 v2) { return dots_onplane(u1,u2,v1,v2)&&opposite_side(u1,u2,v1,v2)&&opposite_side(v1,v2,u1,u2); }
// 判斷線段是否與空間三角形相交(包括交於邊界和(部分)包含)
int intersect_in(line3 l, plane3 s) { 
  return!same_side(l.a,l.b,s)&&!same_side(s.a,s.b,l.a,l.b,s.c)&&
    !same_side(s.b,s.c,l.a,l.b,s.a)&&!same_side(s.c,s.a,l.a,l.b,s.b);
}
int intersect_in(point3 l1, point3 l2, point3 s1, point3 s2, point3 s3) {
  return!same_side(l1,l2,s1,s2,s3)&&!same_side(s1,s2,l1,l2,s3)&&
    !same_side(s2,s3,l1,l2,s1)&&!same_side(s3,s1,l1,l2,s2);
}
// 判斷線段是否與空間三角形相交(不包括交於邊界和(部分)包含)
int intersect_ex(line3 l, plane3 s) {
  return opposite_side(l.a,l.b,s)&&opposite_side(s.a,s.b,l.a,l.b,s.c)&&
    opposite_side(s.b,s.c,l.a,l.b,s.a)&&opposite_side(s.c,s.a,l.a,l.b,s.b);
}
int intersect_ex(point3 l1, point3 l2, point3 s1, point3 s2, point3 s3) {
  return opposite_side(l1,l2,s1,s2,s3)&&opposite_side(s1,s2,l1,l2,s3)&&
    opposite_side(s2,s3,l1,l2,s1)&&opposite_side(s3,s1,l1,l2,s2);
}
// 計算兩條直線的交點(注意:先判斷直線是否共面和平行)
// 線段交點請另判線段相交
point3 intersection(line3 u, line3 v) {
  point3 ret=u.a;
  double t=((u.a.x-v.a.x)*(v.a.y-v.b.y)-(u.a.y-v.a.y)*(v.a.x-v.b.x))/((u.a.x-u.b.x)*(v.a.y-v.b.y)-(u.a.y-u.b.y)*(v.a.x-v.b.x));
  ret.x+=(u.b.x-u.a.x)*t;  ret.y+=(u.b.y-u.a.y)*t;  ret.z+=(u.b.z-u.a.z)*t;
  return ret;
}
point3 intersection(point3 u1, point3 u2, point3 v1, point3 v2) {
  point3 ret=u1;
  double t=((u1.x-v1.x)*(v1.y-v2.y)-(u1.y-v1.y)*(v1.x-v2.x))/((u1.x-u2.x)*(v1.y-v2.y)-(u1.y-u2.y)*(v1.x-v2.x));
  ret.x+=(u2.x-u1.x)*t;  ret.y+=(u2.y-u1.y)*t;  ret.z+=(u2.z-u1.z)*t;
  return ret;
}
// 計算直線與平面的交點(注意:先判斷直線是否平行,並保證三點不共線!)
// 線段與平面交點請另判
point3 intersection(line3 l, plane3 s) {
  point3 ret=pvec(s);
  double t=(ret.x*(s.a.x-l.a.x)+ret.y*(s.a.y-l.a.y)+ret.z*(s.a.z-l.a.z))/(ret.x*(l.b.x-l.a.x)+ret.y*(l.b.y-l.a.y)+ret.z*(l.b.z-l.a.z));
  ret.x=l.a.x+(l.b.x-l.a.x)*t; ret.y=l.a.y+(l.b.y-l.a.y)*t; ret.z=l.a.z+(l.b.z-l.a.z)*t;
  return ret;
}
point3 intersection(point3 l1, point3 l2, point3 s1, point3 s2, point3 s3) {
  point3 ret=pvec(s1,s2,s3);
  double t=(ret.x*(s1.x-l1.x)+ret.y*(s1.y-l1.y)+ret.z*(s1.z-l1.z))/(ret.x*(l2.x-l1.x)+ret.y*(l2.y-l1.y)+ret.z*(l2.z-l1.z));
  ret.x=l1.x+(l2.x-l1.x)*t; ret.y=l1.y+(l2.y-l1.y)*t; ret.z=l1.z+(l2.z-l1.z)*t;
  return ret;
}
// 計算兩平面的交線(注意:先判斷是否平行,並保證三點不共線!)
line3 intersection(plane3 u, plane3 v) {
  line3 ret;
  ret.a=parallel(v.a,v.b,u.a,u.b,u.c)?intersection(v.b,v.c,u.a,u.b,u.c):intersection(v.a,v.b,u.a,u.b,u.c);
  ret.b=parallel(v.c,v.a,u.a,u.b,u.c)?intersection(v.b,v.c,u.a,u.b,u.c):intersection(v.c,v.a,u.a,u.b,u.c);
  return ret;
}
line3 intersection(point3 u1, point3 u2, point3 u3, point3 v1, point3 v2, point3 v3) {
  line3 ret;
  ret.a=parallel(v1,v2,u1,u2,u3)?intersection(v2,v3,u1,u2,u3):intersection(v1,v2,u1,u2,u3);
  ret.b=parallel(v3,v1,u1,u2,u3)?intersection(v2,v3,u1,u2,u3):intersection(v3,v1,u1,u2,u3);
  return ret;
}
// 點到直線的距離
double ptoline(point3 p, line3 l) { return vlen(xmult(subt(p,l.a),subt(l.b,l.a)))/edist(l.a,l.b); }
double ptoline(point3 p, point3 l1, point3 l2) { return vlen(xmult(subt(p,l1),subt(l2,l1)))/edist(l1,l2); }
// 計算點到平面的距離
double ptoplane(point3 p, plane3 s) { return fabs(dmult(pvec(s),subt(p,s.a)))/vlen(pvec(s)); }
double ptoplane(point3 p, point3 s1, point3 s2, point3 s3) { return fabs(dmult(pvec(s1,s2,s3),subt(p,s1)))/vlen(pvec(s1,s2,s3)); }
// 計算直線到直線的距離
double linetoline(line3 u, line3 v) { 
  point3 n=xmult(subt(u.a,u.b),subt(v.a,v.b));
  return fabs(dmult(subt(u.a,v.a),n))/vlen(n);
}
double linetoline(point3 u1, point3 u2, point3 v1, point3 v2) {
  point3 n=xmult(subt(u1,u2),subt(v1,v2));
  return fabs(dmult(subt(u1,v1),n))/vlen(n);
}
// 空間兩直線夾角的cos值
double angle_cos(line3 u, line3 v) { return dmult(subt(u.a,u.b),subt(v.a,v.b))/vlen(subt(u.a,u.b))/vlen(subt(v.a,v.b)); }
double angle_cos(point3 u1, point3 u2, point3 v1, point3 v2) { return dmult(subt(u1,u2),subt(v1,v2))/vlen(subt(u1,u2))/vlen(subt(v1,v2)); }
// 兩平面夾角的cos值
double angle_cos(plane3 u, plane3 v) { return dmult(pvec(u),pvec(v))/vlen(pvec(u))/vlen(pvec(v)); }
double angle_cos(point3 u1, point3 u2, point3 u3, point3 v1, point3 v2, point3 v3) { return dmult(pvec(u1,u2,u3),pvec(v1,v2,v3))/vlen(pvec(u1,u2,u3))/vlen(pvec(v1,v2,v3)); }
// 直線與平面夾角sin值
double angle_sin(line3 l, plane3 s) { return dmult(subt(l.a,l.b),pvec(s))/vlen(subt(l.a,l.b))/vlen(pvec(s)); }
double angle_sin(point3 l1, point3 l2, point3 s1, point3 s2, point3 s3) { return dmult(subt(l1,l2),pvec(s1,s2,s3))/vlen(subt(l1,l2))/vlen(pvec(s1,s2,s3)); }


