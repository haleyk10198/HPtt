//点1——n，dist[i][j]是两点间边的权重/距离，如果不存在边就调成999999，n是点个数
double prim(vector<vector<double>> dist,int n){//double 还是 int 由权重的类型决定
    double lowcost[n+1];    //double 还是 int 由权重的类型决定
    int mst[n+1];
    for(int i=2;i<=n;i++)
    {
        lowcost[i] = dist[1][i];
        mst[i] = 1;
    }
    lowcost[1] = 0;
    mst[1] = 0;
    double minD;            //double 还是 int 由权重的类型决定
    int minIndex;
    double sum=0;           //double 还是 int 由权重的类型决定
    for(int i=2;i<=n;i++)
    {
        minD = 99999999;
        minIndex = 0;
        for(int j=2;j<=n;j++)
        {
            if(minD>lowcost[j] && mst[j]!=0)
            {
                minD = lowcost[j];
                minIndex = j;
            }
        }
        sum+=minD;
        lowcost[minIndex] = 0;
        mst[minIndex] = 0;
        for(int k=2;k<=n;k++)
        {
            if(dist[minIndex][k]<lowcost[k])
            {
                lowcost[k] = dist[minIndex][k];
                mst[k] = minIndex;
            }
        }
    }
    return sum;

}