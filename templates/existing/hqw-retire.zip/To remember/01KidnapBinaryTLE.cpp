#include <algorithm>
#include <iostream>
#include <vector>

using namespace std;
typedef pair<int,int> pp;

void divider(int w,int p,int num,vector<pp> & object){
    int cur = 1;
    while(num>cur)
    {
        int ww = w*cur;
        int pp = p*cur;
        object.push_back(make_pair(ww,pp));
        num-=cur;
        cur<<=1;
    }
    int ww = w*num;
    int pp = p*num;
    object.push_back(make_pair(ww,pp));
}
int main(){

    int N,M,w,p;
    cin>>N>>M;
    vector<vector<int>> a(12);
    for(int i=0;i<12;i++)
        a[i].resize(12);

    for(int i=0;i<N;i++)
    {
        cin>>w>>p;
        a[w][p]++;
    }
    vector<pp> object;
    for(int i=0;i<12;i++)
        for(int j=0;j<12;j++)
        {
            if(a[i][j])
                divider(i,j,a[i][j],object);
        }
    vector<vector<int>> c(object.size()+1);
    for(int i=0;i<object.size()+1;i++)
        c[i].resize(M+1);
    for(int i=1;i<=object.size();i++)
        for(int j=object[i-1].first;j<=M;j++)
        {
//            if(object[i-1].first>j)
//                c[i][j]=c[i-1][j];
//            else
//            {
                c[i][j]=max(c[i-1][j],c[i-1][j-object[i-1].first]+object[i-1].second);
//            }
        }
    cout<<c[object.size()][M];
    return 0;
}