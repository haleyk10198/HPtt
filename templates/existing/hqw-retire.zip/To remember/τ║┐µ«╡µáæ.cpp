//区间增减,操作范围[1,n]（被20行的代码所限制),maxn调大一些，比如题目的两倍，设差几十会爆炸
#define lson l , m , rt << 1
#define rson m + 1 , r , rt << 1 | 1

ll lazy[maxn<<2];
ll sum[maxn<<2];

void putup(int rt)
{
    sum[rt] = sum[rt<<1] + sum[rt<<1|1];
}

void putdown(int rt,int m)
{
    if (lazy[rt])
    {
        lazy[rt<<1] += lazy[rt];
        lazy[rt<<1|1] += lazy[rt];
        sum[rt<<1] += lazy[rt] * (m - (m >> 1));
        sum[rt<<1|1] += lazy[rt] * (m >> 1);
        lazy[rt] = 0;
    }
}

void build(int l,int r,int rt) {
    lazy[rt] = 0;
    if (l == r)
    {
//        scanf("%lld",&sum[rt]);
        sum[rt]=0;
        return ;
    }
    int m = (l + r) >> 1;
    build(lson);
    build(rson);
    putup(rt);
}

void update(int L,int R,int c,int l,int r,int rt)
{
    if (L <= l && r <= R)
    {
        lazy[rt] += c;
        sum[rt] += (ll)c * (r - l + 1);
        return ;
    }
    putdown(rt , r - l + 1);
    int m = (l + r) >> 1;
    if (L <= m) update(L , R , c , lson);
    if (m < R) update(L , R , c , rson);
    putup(rt);
}

ll query(int L,int R,int l,int r,int rt)
{
    if (L <= l && r <= R)
    {
        return sum[rt];
    }
    putdown(rt , r - l + 1);
    int m = (l + r) >> 1;
    ll ret = 0;
    if (L <= m) ret += query(L , R , lson);
    if (m < R) ret += query(L , R , rson);
    return ret;
}

int main()
{
    build(1 , n , 1);
    query(a , b , 1 , n , 1);//[a,b]操作范围，1,n初始标号，1是rt
    update(a , b , c , 1 , n , 1);
}