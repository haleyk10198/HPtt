//点编号随意
//返回一颗子树的直径（最长路长度），初始通过控制p来得到想要的子树的直径
vector<int> mpp[maxn];
int ans;
int dfs(int u,int p){
    int sum = 0;
    int max1 = 0,max2 = 0;
    for(auto v:mpp[u])
        if(v!=p)
        {
            int tmp = dfs(v,u);
            sum = max(sum, tmp);
            if(ans>max1)
                max2 = max1,max1 = ans;
            else
                max2 = max(ans,max2);
        }
    sum = max(sum, max1+max2);
    ans = max1 + 1;
    return sum;
}