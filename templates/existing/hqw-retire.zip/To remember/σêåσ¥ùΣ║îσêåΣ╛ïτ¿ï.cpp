const int SQ = 500, MN = 2e5 + 200;
vector<int> num[SQ];
int a[MN];
void recalc(int p){
    num[p].clear();
    for(int i=p*SQ;i<(p+1)*SQ;i++)
        num[p].pb(a[i]);
    sort(num[p].begin(),num[p].end());
}
int ans(int p, int l1, int r1){
    return lower_bound(num[p].begin(),num[p].end(),r1)-upper_bound(num[p].begin(),num[p].end(),l1);
}
int query(int l,int r,int l1,int r1){
    if(l1>r1)
        swap(l1,r1);
    int ret = 0;
    while(l%SQ && l<r){
        if(a[l]>l1 && a[l]<r1)
            ret++;
        l++;
    }
    while(r%SQ && l<r){
        if(a[r-1]>l1 && a[r-1]<r1)
            ret++;
        r--;
    }
    for(int i=(l/SQ);i<(r/SQ);i++)
        ret += ans(i,l1,r1);
    return ret;
}

int swp(int i,int j){
    int ret = 1;
    swap(a[i],a[j]);
    recalc(i/SQ);
    recalc(j/SQ);
    ret += 2*query(i+1,j,a[i],a[j]);
    if(a[i]<a[j])
        return -1*ret;
    else
        return ret;
}

int main(){
    int n,q;
    cin>>n>>q;
    iota(a,a+n,0);
    for(int i=0;i<n;i++)
        num[i/SQ].pb(i);
    long long ans = 0;
    for(int i=0;i<q;i++){
        int l,r;
        cin>>l>>r;
        if(l!=r){
            l--;r--;
            if(l>r)
                swap(l,r);
            ans+=swp(l,r);
        }
        cout<<ans<<endl;
    }
    return 0;
}

















