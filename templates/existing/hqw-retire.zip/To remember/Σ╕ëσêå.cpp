//极小值
double l = -1000, r = 1000, m1, m2;
while(r-l>eps)
{
    m1 = (2 * l + r) / 3;
    m2 = (l + 2 * r) / 3;
    if(f(m1)<=f(m2))
        r = m2;
    else
        l = m1;
}
if(f(l));

//极大值
double l = -1000, r = 1000, m1, m2;
while(r-l>eps)
{
    m1 = (2 * l + r) / 3;
    m2 = (l + 2 * r) / 3;
    if(f(m1)<=f(m2))
        l = m1;
    else
        r = m2;
}
if(f(r));

//如果是求多个变量的convex函数极值，多个变量一个个三分下去就行了

//int 极小值upper_bound 范围(L,R)
ll cal(int M)
{
}
int solveR(int L, int R,int i)
{
    int M, RM;
    while (L + 1 < R)
    {
        M = (L + R) / 2;
        RM = (M + R) / 2;
        if (calc(M) < calc(RM)) //计算最小值,若为最大值则>
            R = RM;
        else
            L = M;
    }
    return L;
}