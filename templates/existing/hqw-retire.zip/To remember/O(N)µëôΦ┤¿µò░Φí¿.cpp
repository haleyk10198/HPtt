const int NP=100005;
int ispri[NP]= {},prime[NP],pcnt=0;
void getprime()
{
    ispri[0]=ispri[1]=1;
    for (int i=2; i<NP; i++)
    {
        if (ispri[i]==0)
            prime[++pcnt]=i;
        for(int j=1;j<=pcnt;j++)
        {
            if(1LL*i*prime[j]>=NP)
                break;
            ispri[i*prime[j]] = 1;
            if(i%prime[j]==0)
                break;
        }
    }
}