//点的编号[1,n]
const int N = int(1e5)+10;
const int LOGN = 20;
vector<int> mpp[N];
int level[N],size[N],findu[N],top[N],val[N];
int DP[LOGN][N];
int n,pcnt;//seg tree has variable m, be careful
/*Using dsu of a tree */

void init(){
    for(int i=0;i<N;i++)
        mpp[i].clear();
    mem(level,0);
    mem(size,0);
    mem(findu,0);
    mem(top,0);
    mem(val,0);
    mem(DP,0);
    pcnt = 0;
}
/*----------- Pre-Processing ------------*/
void dfs0(int u)
{
    size[u] = 1;
    for(auto v:mpp[u])
        if(v!=DP[0][u])
        {
            DP[0][v]=u;
            level[v]=level[u]+1;
            dfs0(v);
            size[u] += size[v];
        }
}
void dfs1(int u,int chain){
    int k = 0;pcnt++;
    findu[u] = pcnt;// u 在线段树中的编号, 线段树[1,pcnt]
    top[u] = chain;
    for(auto v:mpp[u])
        if(level[v]>level[u] && size[v]>size[k])
            k = v;
    if(k==0)return;
    dfs1(k,chain);
    for(auto v:mpp[u])
        if(level[v]>level[u] && k!=v)
            dfs1(v,v);
}
void preprocess()
{
    size[0] = 0;
    level[1]=0;
    DP[0][1]=0;
    pcnt = 0;
    dfs0(1);
    for(int i=1;i<LOGN;i++)
        for(int j=1;j<n+1;j++)
            DP[i][j] = DP[i-1][DP[i-1][j]];
    dfs1(1,1);
}
int lca(int a,int b)
{
    if(level[a]>level[b])swap(a,b);
    int d = level[b]-level[a];
    for(int i=0;i<LOGN;i++)
        if(d&(1<<i))
            b=DP[i][b];
    if(a==b)return a;
    for(int i=LOGN-1;i>=0;i--)
        if(DP[i][a]!=DP[i][b])
            a=DP[i][a],b=DP[i][b];
    return DP[0][a];
}

/*----------- seg-tree ------------*/
//区间增减,操作范围[1,n]（被20行的代码所限制),maxn调大一些，比如题目的两倍，设差几十会爆炸
#define lson l , m , rt << 1
#define rson m + 1 , r , rt << 1 | 1

ll sum[maxn<<2];

void putup(int rt)
{
    sum[rt] = sum[rt<<1] + sum[rt<<1|1];
}

void build(int l,int r,int rt) {
    if (l == r)
    {
//        scanf("%lld",&sum[rt]);
        sum[rt]=0;
        return ;
    }
    int m = (l + r) >> 1;
    build(lson);
    build(rson);
    putup(rt);
}

void update(int L,int R,int c,int l,int r,int rt)
{
    if (L <= l && r <= R)
    {
        sum[rt] = (ll)c * (r - l + 1);
        return ;
    }
    int m = (l + r) >> 1;
    if (L <= m) update(L , R , c , lson);
    if (m < R) update(L , R , c , rson);
    putup(rt);
}

ll query(int L,int R,int l,int r,int rt)
{
    if (L <= l && r <= R)
    {
        return sum[rt];
    }
    int m = (l + r) >> 1;
    ll ret = 0;
    if (L <= m) ret += query(L , R , lson);
    if (m < R) ret += query(L , R , rson);
    return ret;
}

/*----------- dsu-query ------------*/
void updateSuf(int x,int f,int k){//f is accester of x
    while(top[x]!=top[f])
    {
        update(findu[top[x]],findu[x],k,1,n,1);
        x = DP[0][top[x]];
    }
    update(findu[f],findu[x],k,1,n,1);
}
void updateDsu(int x,int y,int k){//x to y add k
    int t = lca(x,y);
    updateSuf(x,t,k);
    updateSuf(y,t,k);
    updateSuf(t,t,-k);
}

ll querySuf(int x,int f){
    ll res = 0;
    while(top[x]!=top[f])
    {
        res += query(findu[top[x]],findu[x],1,n,1);
        x = DP[0][top[x]];
    }
    res += query(findu[f],findu[x],1,n,1);
    return res;
}
ll querySum(int x,int y){
    int t = lca(x,y);
    ll res = querySuf(x,t);
    res += querySuf(y,t);
    res -= query(findu[t],findu[t],1,n,1);
    return res;
}