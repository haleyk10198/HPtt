int dfn[maxn],low[maxn],cnt = 0;
int st[maxn], top = 0;
vector<vector<int>> block;
void cutBlockInit(){
    top = cnt = 0;
    block.clear();
}
void cutBlock(int u){
    dfn[u] = low[u] = ++cnt;
    st[++top] = u;
    for (int i=he[u]; i!=-1; i=E[i].next)
    {
        int v = E[i].v;
        if(dfn[v] == 0)
        {
            cutBlock(v);
            low[u] = min(low[u], low[v]);
            if(low[v] >= dfn[u])//u is a cut point
            {
                vector<int> tmp;
                while(true)
                {
                    tmp.pb(st[top]);
                    if(st[top--] == v)
                        break;
                }
                tmp.pb(u);
                block.pb(tmp);
            }
        }
        else
            low[u] = min(low[u], dfn[v]);
    }
}