typedef pair<ll,vector<int>> pp;
pp mergeCount(vector<int> A, vector<int> B){
    vector<int> C;
    int i=0,j=0;
    ll count = 0;
    while(i<A.size() && j<B.size())
    {
        C.pb(min(A[i],B[j]));
        if(B[j]<A[i])
            count+=A.size()-i,j++;
        else
            i++;
    }
    while(i<A.size())
        C.pb(A[i++]);
    while(j<B.size())
        C.pb(B[j++]);
    return {count,C};
}
pp sortCount(vector<int> L){
    if(L.size()==1)
        return {0,L};
    vector<int> A,B;
    loop(0,L.size()/2)
        A.pb(L[i]);
    loop(L.size()/2,L.size())
        B.pb(L[i]);
    pp rA = sortCount(A);
    pp rB = sortCount(B);
    pp r = mergeCount(rA.second,rB.second);
    r.first = rA.first+rB.first+r.first;
    return r;
}

//BIT做法,a[i]<=1e6才能用,否则得离散化
int ans = 0;
for (int i=1;i<=n;i++)
    update(0,a[i]-1,1),ans+=ask(a[i]);

//三元逆序BIT做法，a[i]<=1e6才能用,否则得离散化
int ans = 0;
for(int i=1;i<=n;i++)
    update(0,0,a[i]-1,1),update(1,0,a[i]-1,ask(0,a[i])),ans += ask(1,a[i]);







