#define lsonp l,m
#define rsonp m+1,r
const int NN = maxn*25;
int sum[NN],ln[NN],rn[NN];
int tot,root[maxn];
void PushUp(int k)
{
    sum[k]=sum[ln[k]]+sum[rn[k]];
}
int buildp(int l,int r)
{
    int k=++tot;
    if (l == r)
    {
        sum[k]=0;
        return k;
    }
    int m = (l + r) >> 1;
    ln[k]=buildp(lsonp);
    rn[k]=buildp(rsonp);
    PushUp(k);
    return k;
}
int updatep(int o,int L,int c,int l,int r)
{
    int k=++tot;
    sum[k]=sum[o];
    ln[k]=ln[o];
    rn[k]=rn[o];
    if (L == l && l == r)
    {
        sum[k]+=c;
        return k;
    }
    int m = (l + r) >> 1;
    if (L <= m) ln[k]=updatep(ln[o], L , c , lsonp);
    else rn[k]=updatep(rn[o], L , c , rsonp);
    PushUp(k);
    return k;
}
int queryp(int a,int b,int L,int l,int r)
{
    if (l==r) return l;
    int m = (l + r) >> 1;
    int tmp=sum[ln[b]]-sum[ln[a]];
    if (L <= tmp) return queryp(ln[a], ln[b], L , lsonp);
    return queryp(rn[a], rn[b], L-tmp , rsonp);
}
int main()
{
    root[0]=buildp(1,n);
    for (int i=1; i<=n; i++)
        root[i]=updatep(root[i-1],pos,val,1,n);
    queryp(root[a-1],root[b],pos,1,n);
    return 0;
}
