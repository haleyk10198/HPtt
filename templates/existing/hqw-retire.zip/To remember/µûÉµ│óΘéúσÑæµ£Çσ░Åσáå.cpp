//斐波那契最小堆
#include <assert.h>
#define TESTNUM 100000
#define POPNUM 100000
template<class T>
class fibonacciNode
{
public:
    T keyValue;
    int degree;
    fibonacciNode *leftBrother;
    fibonacciNode *rightBrother;
    fibonacciNode *child;
    fibonacciNode()
    {
        leftBrother = this;
        rightBrother = this;
        child = NULL;
        degree = 0;
    }
    bool operator<(const fibonacciNode node)
    {
        return keyValue < node.keyValue;
    }
    bool operator<=(const fibonacciNode node)
    {
        return keyValue <= node.keyValue;
    }
    bool operator==(const fibonacciNode node)
    {
        return keyValue == node.keyValue;
    }
};

template<class T>
class CFibonacci
{
private:
    fibonacciNode<T> *minH;                     //指向最小结点
    int keyNum;                                 //结点的个数
    int maxDegree;                              //所有结点组成一棵二项树时第一层孩子结点的最大个数

private:
    void clearRecursive(fibonacciNode<T> *pCurrentNode);            //递归的释放内存空间
    inline void improveChild();                 //将当前最小结点的孩子结点提升到root层
    inline void deleteMinNode();                //删除当前最小结点

    inline void conslidate();                   //最小值出队列后，其它结点的合并
    inline fibonacciNode<T> *removeNode();      //合并操作时，用于将minH指向的结点从root队列中移除，但不delete
    //removerNode()的正确理解参考合并操作
    inline void linkNode(fibonacciNode<T> *x, fibonacciNode<T> *y);         //将树根为y的子树挂载到结点x下
    fibonacciNode<T> **cons;                    //用于合并队列时指向root结点
    inline void combineCons();                  //degree相同的合并为一个root并放入cons中，且此时degree+1
    inline void linkCons();                     //将cons中的结点重新串联为斐波那契堆

public:
    CFibonacci();
    ~CFibonacci();

public:
    void push(const T node);
    void pop();
    T top();
    void clear();

};

template<class T>
CFibonacci<T>::CFibonacci()
        :minH(NULL), keyNum(0)
{
    maxDegree = int(log(TESTNUM * 1.0) / log(2.0)) + 1;
    cons = new fibonacciNode<T> *[maxDegree];
    for (int i=0; i<maxDegree; ++i)
    {
        *(cons + i) = NULL;
    }
}

template<class T>
CFibonacci<T>::~CFibonacci()
{
    if (minH)
    {
        clear();
    }
    delete []cons;
}

template<class T>
void CFibonacci<T>::push(const T node)
{
    fibonacciNode<T> *newNode = new fibonacciNode<T>;
    newNode->keyValue = node;
    keyNum ++;
    if (!minH)
    {
        minH = newNode;
        return;
    }
    newNode->leftBrother = minH;
    newNode->rightBrother = minH->rightBrother;
    minH->rightBrother->leftBrother = newNode;
    minH->rightBrother = newNode;
    if (*newNode <= *minH)
    {
        minH = newNode;
    }
}

template<class T>
void CFibonacci<T>::improveChild()
{
    fibonacciNode<T> *pCurrentNode;

    pCurrentNode = minH->child;

    fibonacciNode<T> *pTempNode;
    pTempNode = minH->rightBrother;

    pCurrentNode->rightBrother->leftBrother = minH;
    minH->rightBrother = pCurrentNode->rightBrother;

    pTempNode->leftBrother = pCurrentNode;
    pCurrentNode->rightBrother = pTempNode;
}

template<class T>
void CFibonacci<T>::deleteMinNode()
{
    fibonacciNode<T> *pCurrentNode;
    pCurrentNode = minH->rightBrother;

    minH->leftBrother->rightBrother = pCurrentNode;
    pCurrentNode->leftBrother = minH->leftBrother;

    delete minH;
    minH = pCurrentNode;
}

template<class T>
void CFibonacci<T>::pop()
{
    assert(keyNum>0);
    keyNum--;

    if (minH->child)
    {
        improveChild();
    }

    if (minH == minH->rightBrother)
    {
        delete minH;
        minH = NULL;
    }
    else
    {
        deleteMinNode();
        conslidate();
    }
}

template<class T>
T CFibonacci<T>::top()
{
    assert(keyNum>0);
    return minH->keyValue;
}

template<class T>
void CFibonacci<T>::clear()
{
    if (!minH)
    {
        return;
    }
    keyNum = 0;
    clearRecursive(minH);
    minH = NULL;
}

template<class T>
void CFibonacci<T>::clearRecursive(fibonacciNode<T> *pCurrentNode)
{
    fibonacciNode<T> *pCurrentRight;
    //处理孩子
    if (pCurrentNode->child)
    {
        clearRecursive(pCurrentNode->child);
        pCurrentNode->child = NULL;
    }
    //处理兄弟
    if (pCurrentNode != pCurrentNode->rightBrother)
    {
        pCurrentRight = pCurrentNode->rightBrother;
        pCurrentNode->leftBrother->rightBrother = pCurrentRight;
        pCurrentRight->leftBrother = pCurrentNode->leftBrother;
        delete pCurrentNode;
        clearRecursive(pCurrentRight);
    }
    else
    {
        delete pCurrentNode;
    }
}

template<class T>
fibonacciNode<T> *CFibonacci<T>::removeNode()
{
    fibonacciNode<T> *x = minH;
    //移除minH
    if (minH->rightBrother == minH)
    {
        minH = NULL;
    }
    else
    {
        minH->leftBrother->rightBrother = minH->rightBrother;
        minH->rightBrother->leftBrother = minH->leftBrother;
        minH = minH->rightBrother;
    }
    x->leftBrother = x;
    x->rightBrother = x;

    return x;
}

template<class T>
void CFibonacci<T>::linkNode(fibonacciNode<T> *x, fibonacciNode<T> *y)
{
    if (!x->child)
    {
        x->child = y;
    }
    else
    {
        x->child->rightBrother->leftBrother = y;
        y->rightBrother = x->child->rightBrother;

        x->child->rightBrother = y;
        y->leftBrother = x->child;
    }
    x->degree++;
}

template<class T>
void CFibonacci<T>::combineCons()
{
    fibonacciNode<T> *x, *y;
    int degree;
    while (NULL != minH)
    {
        x = removeNode();
        degree = x->degree;
        while (NULL != *(cons + degree))
        {
            y = *(cons + degree);
            if (*y < *x)
            {
                swap(x, y);
            }
            linkNode(x, y);                 //将y合并为x的孩子
            *(cons + degree) = NULL;
            degree++;
        }
        *(cons + degree) = x;
    }
}

template<class T>
void CFibonacci<T>::linkCons()
{
    for (int i=0; i<maxDegree; ++i)
    {
        if (*(cons + i))
        {
            if (!minH)
            {
                minH = *(cons + i);
            }
            else
            {
                minH->rightBrother->leftBrother = *(cons + i);
                (*(cons + i))->rightBrother = minH->rightBrother;

                minH->rightBrother = *(cons + i);
                (*(cons + i))->leftBrother = minH;
                minH =*(*(cons + i)) < *minH ? (*(cons + i)):minH;
            }
            *(cons + i) = NULL;
        }
    }
}

template<class T>
void CFibonacci<T>::conslidate()
{
    //合并孩子个数相同的结点
    combineCons();

    //将cons中结点都重新加到根表中，且找出最小根
    linkCons();
}