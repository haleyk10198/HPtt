//区间加减线段树,操作范围 [0, N)
int N;//和st的范围要设得一样大！
int st[10010];//大小是pos的最大值+1！
void init(){
    mem(st,0);
}
int ask(int pos){
    int tt = 0;
    for(++pos;pos;pos-=(pos&(-pos)))
        tt += st[pos];
    return tt;
}
void upd(int pos, int v){//[pos,N) 加 v
    for(++pos;pos<=N;pos+=(pos&(-pos)))
        st[pos] += v;
    return;
}
void update(int l, int r, int v){//[l,r] 加 v
    upd(l,v);
    upd(r+1,-v);
}
//区间乘除线段树,操作范围 [0, N)
int N;
int st[10010];
void init(){
    rep(i,0,N)//注意要把 N 也初始化
        st[i] = 1;
}
int ask(int pos){
    int tt = 1;
    for(++pos;pos;pos-=(pos&(-pos)))
        tt *= st[pos];
    return tt;
}
void upd(int pos, int v){
    for(++pos;pos<=N;pos+=(pos&(-pos)))
        st[pos] *= v;
    return;
}