#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <algorithm>
using namespace std;

struct Point
{
    double x;
    double y;
    double angle;
};
Point p[100003];
bool cmp(Point a,Point b)
{
    return a.angle<b.angle;
}
int main()
{
    int n;
    scanf(" %d",&n);
    for(int i=0; i<n; i++)
    {
        scanf(" %lf %lf",&p[i].x,&p[i].y);
        p[i].angle = atan2(p[i].y,p[i].x);
    }
    sort(p,p+n,cmp);
    p[n].angle = p[0].angle + 2 * acos(-1.0);
    double ans = 2*acos(-1.0);

    for(int i=0; i<n; i++)
    {
        ans = min(ans,2 * acos(-1.0) - fabs(p[i+1].angle - p[i].angle));
    }
    printf("%lf\n",ans*180.0/acos(-1.0));
    return 0;
}
