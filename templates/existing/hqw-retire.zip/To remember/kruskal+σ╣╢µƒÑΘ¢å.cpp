int f[1000005],rk[1000005];             //这里是数据量上限
int finds(int x) //非递归                //找到自己的掌门
{
    int k,j,r;
    r=x;
    while(r!=f[r])
        r=f[r];
    k=x;
    while(k!=r)
    {
        j=f[k];
        f[k]=r;
        k=j;
    }
    return r;
}
//int finds(int x) //递归
//{
//    return f[x]==x?x:f[x]=finds(f[x]);
//}
void uni(int a,int b)
{
    a=finds(a);
    b=finds(b);
    if (a==b) return;
    if (rk[a]>rk[b]) f[b]=a;
    else
    {
        if (rk[a]==rk[b]) rk[b]++;
        f[a]=b;
    }
}
bool sameSet(int a,int b)               //判断a和b是否连通/在同一集合
{
    a=finds(a);
    b=finds(b);
    if (a==b) return true;
    return false;
}
void init(int n)
{
    memset(rk,0,sizeof(rk));
    for (int i=1; i<=n; i++)
        f[i]=i;
}
struct edge{
    int u,v;
    double dist;
};
bool cmp(edge a, edge b){
    return a.dist>b.dist;
}
double kruskal(vector<edge> myEdge, int n){     //返回double还是int由权值类型决定
    sort(myEdge.begin(),myEdge.end(),cmp);
    init(n);
    if(myEdge.empty())
        return 1000000;
    edge last = myEdge.back();
    myEdge.pop_back();
    uni(last.u,last.v);
    double sum = last.dist;                 //double还是int由权值类型决定
    while(!myEdge.empty())
    {
        last = myEdge.back();
        myEdge.pop_back();
        if(!sameSet(last.u,last.v))
        {
            uni(last.u,last.v);
            sum+=last.dist;
        }
    }
    for(int i=2;i<=n;i++)
    {
        if(!sameSet(1,i))
            return 1000000;
    }
    return sum;
}