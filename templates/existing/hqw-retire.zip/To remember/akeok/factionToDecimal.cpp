//找出无限循环小数的循环节，有限就返回-1，O(循环节len)复杂度
string factionToDecimal(int numerator, int denominator){
    string res;
    map<int,int> mp;
    mp.clear();
    int rem = numerator % denominator;
    while((rem != 0) && (mp.find(rem)==mp.end()))
    {
        mp[rem] = res.length();
        rem = rem*10;
        int res_part = rem / denominator;
        res += to_string(res_part);
        rem = rem % denominator;
    }
    return (rem==0)?"-1":res.substr(mp[rem]);
}