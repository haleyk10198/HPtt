//log(n)求一个n的约数，实际上就是一个质因数分解，约数个数等于所有（prime factors的个数+1）的累积
//一个数的约数个数不超过cubic_root(n)
ll getFactorNum(long long n){
    ll ans = 1;
    for(int i=1;1LL*prime[i]*prime[i]<=n;i++)
        if(n%prime[i]==0)
        {
            ll c = 1;
            while(n%prime[i]==0)
                n/=prime[i], c++;
            ans*=c;
        }
    if(n>1)
        ans*=2;
    return ans;
}