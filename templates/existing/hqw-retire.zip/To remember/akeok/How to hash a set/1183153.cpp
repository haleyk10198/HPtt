#include <bits/stdc++.h>

#define eb emplace_back
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define INF 0x3f3f3f3f

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
const int N = 300010;

ll mod[2] = {1000*1000*1000+9, 1000*1000*1000+7};
const int B = 2;
int ans;
vi g[N];
ll pot[N][2];
set <pii> s;
bool flag;
pii dfs (int u) {
	pii meu_hash = mp(pot[u][0], pot[u][1]);

	for (auto v : g[u]) {
		pii filho = dfs(v);
		meu_hash.fi = (meu_hash.fi + filho.fi) % mod[0];
		meu_hash.se = (meu_hash.se + filho.se) % mod[1];
	}

	if (!flag) s.insert(meu_hash);
	else {
		ans += s.count(meu_hash);
	}
	return meu_hash;
}
int main (void) {
	pot[0][0] = pot[0][1] = 1;
	for (int i = 1; i < N; i++) {
	for (int j = 0; j < 2; j++) {
		pot[i][j] = (pot[i-1][j] * B) % mod[j];
	}
	}
	int n; scanf("%d", &n);
	for (int i = 0; i < n-1; i++) {
		int pai; scanf("%d", &pai);
		g[pai].pb(i+2);
	}
	dfs(1);
	for (int i = 1; i <= n; i++) g[i].clear();
	for (int i = 0; i < n-1; i++) {
		int pai; scanf("%d", &pai);
		g[pai].pb(i+2);
	}
	flag = true;
	dfs(1);
	cout << ans-1 << endl;
	return 0;
}

