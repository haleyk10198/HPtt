#include <bits/stdc++.h>
using namespace std;
vector<int> a[300020];
vector<int> b[300020];
typedef unsigned long long ull;
pair<ull, ull> c[300020];
pair<ull, ull> f[300020];
pair<ull, ull> g[300020];
void dfs(int x) {
	f[x] = c[x];
	for (int i: a[x]) {
		dfs(i);
		f[x].first ^= f[i].first;
		f[x].second ^= f[i].second;
	}
}
void dgs(int x) {
	g[x] = c[x];
	for (int i: b[x]) {
		dgs(i);
		g[x].first ^= g[i].first;
		g[x].second ^= g[i].second;
	}
}

ull rd() {
	ull a = rand();
	ull b = rand();
	ull c = rand();
	ull d = rand();
	ull e = rand();
	return (a) ^ (b << 15) ^ (c << 30) ^ (d << 45) ^ (e << 60);
}
int main() {
	int n, x;
	scanf("%d", &n);
	for (int i = 2; i <= n; i++) {
		scanf("%d", &x);
		a[x].push_back(i);
	}
	for (int i = 2; i <= n; i++) {
		scanf("%d", &x);
		b[x].push_back(i);
	}
	for (int i = 1; i < n; i++) {
		c[i] = make_pair(rd(), rd());
		c[n].first ^= c[i].first;
		c[n].second ^= c[i].second;
	}
	dfs(1);
	dgs(1);
	set<pair<ull, ull> > s;
	for (int i = 1; i <= n; i++) {
		s.insert(f[i]);
	}
	int z = -1;
	for (int i = 1; i <= n; i++) {
		if (s.find(g[i]) != s.end()) {
			z++;
		}
	}
	printf("%d\n", z);
}