//输入必须没有空格，operand只能是英文大小写字母,否则自己扩展第21行
//求prefix的话，就把input reverse(注意'('和')'要互换)，求出postfix再reverse
int prec(char c){
    if(c == '^')
        return 3;
    else if(c == '*' || c == '/')
        return 2;
    else if(c == '+' || c == '-')
        return 1;
    else
        return -1;
}
string infixToPostfix(string s){
    stack<char> st;
    st.push('N');
    int l = s.length();
    string ns="";
    for(int i=0; i<l; i++)
    {
        // If the scanned character is an operand, add it to output string.
        if((s[i] >= 'a' && s[i] <=' z') || (s[i] >= 'A' && s[i] <= 'Z'))
            ns += s[i];
        // If the scanned character is an ‘(‘, push it to the stack.
        else if(s[i] == '(')
            st.push('(');
        else if(s[i] == ')')
        {
            while(st.top() != 'N' && st.top() != '(')
            {
                char c = st.top();
                st.pop();
                ns += c;
            }
            if(st.top() == '(')
            {
                st.pop();
            }
        }
        //If an operator is scanned
        else
        {
            while(st.top()!='N' && prec(s[i]) <= prec(st.top()))
            {
                char c = st.top();
                st.pop();
                ns += c;
            }
            st.push(s[i]);
        }
    }
    //Pop all the remaining elements from the stack
    while(st.top()!='N')
    {
        char c = st.top();
        st.pop();
        ns += c;
    }
    return ns;
}
//求prefix示范
string s = "a+b*(c^d-e)^(f+g*h)-i";
reverse(s.begin(),s.end());
for(auto &v:s)
{
    if(v=='(')
        v = ')';
    else if(v==')')
        v = '(';
}
string tmp = infixToPostfix(s);
reverse(tmp.begin(),tmp.end());
cout<<tmp;