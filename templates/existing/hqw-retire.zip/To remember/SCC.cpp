//SCC编号[1..SCC()],点编号[1..N]
vector<int> mpp[maxn],mppr[maxn];
int vis[maxn],ord[maxn],color[maxn],b[maxn];
int cnt;
void dfs(int u){
    vis[u] = 1;
    for(auto v:mpp[u])
    {
        if(!vis[v])
            dfs(v);
    }
    ord[u] = cnt++;
}
void dfs2(int u){
    vis[u] = 1;
    color[u] = cnt;
    for(auto v:mppr[u])
    {
        if(!vis[v])
            dfs2(v);
    }
}
void adde_SCC(int u,int v){
    mpp[u].pb(v);
    mppr[v].pb(u);
}
int SCC(int N){
    mem(vis,0);
    cnt = 1;
    rep(i,1,N)
        if(!vis[i])
            dfs(i);
    rep(i,1,N)
        b[i] = i;
    sort(b+1,b+1+N,[](int xx,int yy){
        return ord[xx]>ord[yy];
    });
    mem(vis,0);
    cnt = 1;
    rep(i,1,N)
        if(!vis[b[i]])
        {
            dfs2(b[i]);
            cnt++;
        }
    return cnt-1;
}