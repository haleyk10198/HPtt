int trie[maxn][26];//小写
int ecnt = 1;
void initTrie(){
    mem(trie,0);
}
void addWord(string w){//Time complexity O(w.length())
    int now = 0,cnt=0;
    rep(i,0,w.length()-1)
    {
        if(!trie[now][w[cnt]-'a'])
            trie[now][w[cnt]-'a']=ecnt++;
        now = trie[now][w[cnt]-'a'];
        cnt++;
    }
    //You can add some mark here for now to imply an ending of word
}
//An example to use trie tree
int dfstrie(string w){
    int now = 0,cnt = 0;
    rep(i,0,w.length()-1)
    {
        if(!trie[now][w[cnt]-'a'])
            return i;
        now = trie[now][w[cnt++]-'a'];
    }
    return w.length();
}