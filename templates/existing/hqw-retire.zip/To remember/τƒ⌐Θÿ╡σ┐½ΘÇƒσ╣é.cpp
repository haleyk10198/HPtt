// #include<bits/stdc++.h>  
#include <cassert>  
#define ll long long     
// #define INF 0x3f3f3f3f    
#define MAXN 10010 
#define MOD 1000000007
#define VI  vector<ll>
#define PII pair<ll,ll>
#define SZ(x) ((ll)(x).size())
// using namespace std;   

ll powmod(ll a,ll b){
	ll res = 1;
	a %= MOD;
	assert(b >= 0);
	for(;b;b >>= 1){
		if(b & 1) res = res * a % MOD;
		a = a * a % MOD;
	}
	return res;
}

namespace linear_seq{
	vector<ll> Md;
	ll res[MAXN],base[MAXN],c[MAXN],md[MAXN];
	
	void mul(ll *a,ll *b,ll k){
		for(ll i = 0;i < k + k;i++) c[i] = 0;
		for(ll i = 0;i < k;i++){
			for(ll j = 0;a[i] && j < k;j++)
				c[i + j] = (c[i + j] + a[i] * b[j]) % MOD;
		}
		for(ll i = k + k - 1;i >= k;i--){
			for(ll j = 0;c[i] && j < SZ(Md);j++)
				c[i - k + Md[j]] = (c[i - k + Md[j]] - c[i] * md[Md[j]]) % MOD;
		}
		for(ll i = 0;i < k;i++) a[i] = c[i];
	}
	
	ll solve(ll n,VI a,VI b){
		ll ans = 0,pnt = 0;
		ll k = SZ(a);
		assert(SZ(a) == SZ(b));
		for(ll i = 0;i < k;i++)
			md[k - i - 1] = -a[i];
		md[k] = 1;
		Md.clear();
		for(ll i = 0;i < k;i++) if(md[i]) Md.push_back(i);
		for(ll i = 0;i < k;i++) res[i] = base[i] = 0;
		res[0] = 1;
		while((1ll << pnt) <= n) pnt++;
		for(ll p = pnt;~p;p--){
			mul(res,res,k);
			if((n>>p) & 1){
				for(ll i = k - 1;i >= 0;i--)
					res[i + 1] = res[i];
				res[0] = 0;
				for(ll j = 0;j < SZ(Md);j++){
					res[Md[j]] = (res[Md[j]] - res[k] * md[Md[j]]) % MOD;
				}
			}
		}
		for(ll i = 0;i < k;i++) ans = (ans + res[i] * b[i]) % MOD;
		if(ans < 0) ans += MOD;
		return ans;	
	}
	
	VI BM(VI s){
		VI C(1,1),B(1,1);
		ll L = 0,m = 1,b = 1;
		for(ll n = 0;n < SZ(s);n++){
			ll d = 0;
			for(ll i = 0;i < L + 1;i++) d = (d + (ll)C[i] * s[n - i]) % MOD;
			if(d == 0) ++m;
			else{
				VI T = C;
				ll tmp = MOD - d * powmod(b,MOD - 2) % MOD;
				while(SZ(C) < SZ(B) + m) C.push_back(0);
				for(ll i = 0;i < SZ(B);i++) C[i + m] = (C[i + m] + tmp * B[i]) % MOD;
				if(2 * L <= n){
					L = n + 1 - L;
					B = T;
					b = d;
					m = 1;
				}else{
					++m;
				}
				
			}
		}
		return C;
	}
	
	ll gao(VI a,ll n){
		VI ans = BM(a);
		ans.erase(ans.begin());
		for(ll i = 0;i < SZ(ans);i++) ans[i] = (MOD - ans[i]) % MOD;
		return solve(n,ans,VI(a.begin(),a.begin() + SZ(ans)));
	}
}
   
int main(){     
    ll n;
    while(~scanf("%lld",&n)){
    	printf("%lld\n",linear_seq::gao(VI{1,3,5,10,12,17,19,36,38,43,45,62,64,69,71,136,138,143,145,162,164,169,171,236,238,243,245,262,264,269,271,528,530,535,537,554,556,561,563,628,630,635,637,654,656,661,663,920,922,927,929,946,948,953,955,1020,1022,1027,1029,1046,1048,1053,1055,2080,2082,2087,2089,2106,2108,2113,2115,2180,2182,2187,2189,2206,2208,2213,2215,2472,2474,2479,2481,2498,2500,2505,2507,2572,2574,2579,2581,2598,2600,2605,2607,3632,3634,3639,3641},n-2)); 
	}
}    