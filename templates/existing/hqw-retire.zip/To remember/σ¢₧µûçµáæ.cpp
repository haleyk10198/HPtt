#define MAXN 500005
struct Node
{
    int start, end;
    int length;
    int insertEdg[26];
    int suffixEdg;
};
Node root1, root2;
Node tree[MAXN];
int currNode;
string s;
int ptr;
void insert(int idx){
    int tmp = currNode;
    while(1){
        int curLength = tree[tmp].length;
        if(idx - curLength >= 1 && s[idx] == s[idx-curLength-1])//judge equal
            break;
        tmp = tree[tmp].suffixEdg;
    }
    if(tree[tmp].insertEdg[s[idx]-'a'] != 0)
    {
        currNode = tree[tmp].insertEdg[s[idx]-'a'];
        return;
    }
    ptr++;
    tree[tmp].insertEdg[s[idx]-'a'] = ptr;
    tree[ptr].length = tree[tmp].length + 2;//new palindromic length
    tree[ptr].end = idx;
    tree[ptr].start = idx - tree[ptr].length + 1;

    tmp = tree[tmp].suffixEdg;
    currNode = ptr;
    if(tree[currNode].length==1)
    {
        tree[currNode].suffixEdg = 2;
        return;
    }
    while(1)
    {
        int curLength = tree[tmp].length;
        if(idx - curLength >= 1 && s[idx] == s[idx-curLength-1])//judge equal
            break;
        tmp = tree[tmp].suffixEdg;
    }
    tree[currNode].suffixEdg = tree[tmp].insertEdg[s[idx]-'a'];
}
void init(string inp){
    s = inp;
    root1.length = -1;
    root1.suffixEdg = 1;
    root2.length = 0;
    root2.suffixEdg = 1;

    tree[1] = root1;
    tree[2] = root2;
    ptr = 2;
    currNode = 1;
    int len = s.length();
    for(int i=0;i<len;i++)
        insert(i);
}
void output(){
    cout<<"All distinct palindromic substring:\n";
    for(int i=3;i<=ptr;i++)
    {
        cout<<i-2<<")";
        for(int j=tree[i].start; j<= tree[i].end;j++)
            cout<<s[j];
        cout<<'\n';
    }
}