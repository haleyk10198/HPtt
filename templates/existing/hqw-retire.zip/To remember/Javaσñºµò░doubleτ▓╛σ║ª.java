import java.math.BigInteger;
import java.math.BigDecimal;
import java.util.*;

public class Main {
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        BigDecimal TWO = BigDecimal.valueOf(2);
        BigDecimal FIVE = BigDecimal.valueOf(5);
        
        BigDecimal EPS = new BigDecimal("-0.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001");
        
        BigDecimal L = new BigDecimal("2.2360679774997");
        BigDecimal R = new BigDecimal("2.2360679774998");
        BigDecimal mid = null;
        
        while(L.subtract(R).compareTo(EPS) < 0)
        {
            mid = L.add(R).divide(TWO);
            if(mid.multiply(mid).subtract(FIVE).abs().compareTo(EPS.abs()) < 0)
                break;
            if(mid.multiply(mid).subtract(FIVE).compareTo(EPS) < 0)
                L = mid;
            else
                R = mid;
        }
        
        BigDecimal GOLD = mid.add(BigDecimal.ONE).divide(TWO);
        //System.out.println(GOLD);
        
        while(scanner.hasNext())
        {
            BigDecimal a = scanner.nextBigDecimal();
            BigDecimal b = scanner.nextBigDecimal();
            if(a.compareTo(b) > 0) //保证a是小的
            {
                BigDecimal t = a;
                a = b;
                b = t;
            }
            BigDecimal c = b.subtract(a).multiply(GOLD);
            
            BigInteger aa = a.toBigInteger();
            BigInteger cc = c.toBigInteger();
            if(aa.equals(cc))
                System.out.println("0");
            else 
                System.out.println("1");
        }
    }
}
