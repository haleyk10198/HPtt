struct StudentInfo
{
    int index;
    StudentInfo(int i):index(i){};
    bool operator < (const StudentInfo &s) const
    {
        return index < s.index;//如果用vector sort或set的话，就是从小到大排序，用priority_queue的话，就是大到小
    }
};