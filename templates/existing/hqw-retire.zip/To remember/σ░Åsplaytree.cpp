#define Key_value ch[ch[root][1]][0]
int pre[maxn],ch[maxn][2],key[maxn],size[maxn];
int root;

void NewNode(int &r,int father,int loc,int k)
{
    r = loc;
    pre[r] = father;
    ch[r][0] = ch[r][1] = 0;
    key[r] = k;
    size[r] = 1;
}
void push_up(int r)
{
    size[r] = size[ch[r][0]] + size[ch[r][1]] + 1;
}

void Init()
{
    root = 0;
    ch[root][0] = ch[root][1] = key[root] = size[root] = 0;
    pre[root] = 0;
}

void Rotate(int x,int kind)
{
    int y = pre[x];
    ch[y][!kind] = ch[x][kind];
    pre[ch[x][kind]] = y;
    if(pre[y])
        ch[pre[y]][ch[pre[y]][1]==y] = x;
    pre[x] = pre[y];
    ch[x][kind] = y;
    pre[y] = x;
    push_up(y);
}
void Splay(int r,int goal)
{
    while(pre[r] != goal)
    {
        if(pre[pre[r]] == goal)
            Rotate(r,ch[pre[r]][0] == r);
        else
        {
            int y = pre[r];
            int kind = ch[pre[y]][0]==y;
            if(ch[y][kind] == r)
            {
                Rotate(r,!kind);
                Rotate(r,kind);
            }
            else
            {
                Rotate(y,kind);
                Rotate(r,kind);
            }
        }
    }
    push_up(r);
    if(goal == 0) root = r;
}
int Get_kth(int r,int k)
{
    int t = size[ch[r][0]] + 1;
    if(t == k)return r;
    if(t > k)return Get_kth(ch[r][0],k);
    else return Get_kth(ch[r][1],k-t);
}

void Insert(int loc,int k)
{
    int r = root;
    if(r == 0)
    {
        NewNode(root,0,loc,k);
        return;
    }
    while(ch[r][key[r]<k])
        r = ch[r][key[r]<k];
    NewNode(ch[r][key[r]<k],r,loc,k);
    Splay(ch[r][key[r]<k],0);
}

void erase(int r)
{
    if(!r)return;
    erase(ch[r][0]);
    erase(ch[r][1]);
    Insert(r,weight[r]);
}
int Get_Min(int r)
{
    while(ch[r][0])
    {
        r = ch[r][0];
    }
    return r;
}

//删除根结点
void Delete()
{
    if(ch[root][0] == 0 || ch[root][1] == 0)
    {
        root = ch[root][0] + ch[root][1];
        pre[root] = 0;
        return;
    }
    int k = Get_Min(ch[root][1]);
    Splay(k,root);
    Key_value = ch[root][0];
    root = ch[root][1];
    pre[ch[root][0]] = root;
    pre[root] = 0;
    push_up(root);
}