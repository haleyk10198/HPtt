int dfn[maxn], low[maxn], cnt = 0;
int st[maxn], top = 0;
int id[maxn], numB = 0;
vector<pp> cutE;
void cutEdgeInit(){
    cutE.clear();
    top = cnt = numB = 0;
}
void cutEdge(int u, int par){
    dfn[u] = low[u] = ++cnt;
    st[++top] = u;
    for (int i=he[u]; i!=-1; i=E[i].next)
    {
        int v = E[i].v;
        if(v==par)
            continue;
        if(!dfn[v])
        {
            cutEdge(v, u);
            low[u] = min(low[u], low[v]);
            if(low[v] > dfn[u])//v->u is cut edge
            {
                cutE.pb({u,v});
                //connect v and its 连通分量
                ++numB;
                while(1)
                {
                    id[st[top]] = numB;
                    if(st[top--] == v)
                        break;
                }
            }
        }
        else
            low[u] = min(low[u], dfn[v]);
    }
}