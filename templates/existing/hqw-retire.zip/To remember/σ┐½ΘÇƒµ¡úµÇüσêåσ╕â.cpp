ll seed = 0;
ll nxt(){
    seed ^= 102938711LL;
    seed *= ll(109293);
    seed ^= seed >> 13;
    seed += 1357900102873;
    return seed;
}