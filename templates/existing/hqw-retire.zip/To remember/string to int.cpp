string s;
int num1 = atoi( s.c_str() );
string s = to_string(a);

//int 转化成其他进制的 string
char buf[30];
int a;
itoa(a,buf,16);//转成16进制