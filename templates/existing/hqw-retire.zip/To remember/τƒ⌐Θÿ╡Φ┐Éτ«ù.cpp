const ll MOD = 1e9+7;
inline double Mod(double v,double mod=MOD){
    return v;
}
inline ll Mod(ll v, ll mod = MOD){
    return (v+mod)%mod;
}
typedef vector<vector<ll>> matl;
typedef vector<vector<double>> matd;
template<class T> vector<T> operator*(const T & a,vector<T> v){
    rep(i,0,v.size()-1)
        v[i]=Mod(v[i]*a);
    return v;
}
template<class T> vector<T> operator+(vector<T> v,const vector<T> &w){
    rep(i,0,v.size()-1)
        v[i]=Mod(v[i]+w[i]);
    return v;
}
template<class T> vector<vector<T>> matE(T n){//正方形
    vector<vector<T>> re(n,vector<T>(n));
    rep(i,0,n-1)
        re[i][i] = 1;
    return re;
}
template<class T> vector<vector<T>> matE(vector<vector<T>> mat){//正方形
    return matE((T)(mat.size()));
}
template<class T>
vector<vector<T>> transpose(const vector<vector<T>> &a,vector<vector<T>> &re){//长方形
    re.resize(a[0].size(),vector<T>(a.size()));
    rep(i,0,a[0].size()-1)
        rep(j,0,a.size()-1)
            re[i][j] = a[j][i];
    return re;
}
template<class T> T operator*(const vector<T> &a,const vector<T> &b){
    T re = 0;
    rep(i,0,a.size()-1)
        re = Mod(re+Mod(a[i]*b[i]));
    return re;
}
template<class T> vector<vector<T>> operator*(const vector<vector<T>> &a,const vector<vector<T>> &b_){//长方形
    vector<vector<T>> b;
    transpose(b_,b);
    vector<vector<T>> re(a.size(),vector<T>(b.size()));
    rep(i,0,a.size()-1)
        rep(j,0,b.size()-1)
            re[i][j] = a[i]*b[j];
    return re;
}
template<class T>
vector<vector<T>> pow(vector<vector<T>> a,ll n){//正方形
    vector<vector<T>> re;
    if(n==0)
        return matE(a);
    re = pow(a,n/2);
    return re*re*(n%2?a:matE(a));
}























