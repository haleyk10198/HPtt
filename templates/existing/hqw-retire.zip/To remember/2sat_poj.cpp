//SCC编号[1..SCC()],点编号[0..N]
vector<int> mpp[maxn],mppr[maxn],mpps[maxn],mppd[maxn];
int vis[maxn],ord[maxn],color[maxn],act[maxn];
int cnt;
void sat_init(){
    rep(i,0,maxn-1)
        mpp[i].clear(), mppr[i].clear(), mpps[i].clear(),mppd[i].clear();
}
void dfs(int u,int step){
    vis[u] = 1;
    for(int i=0;i<(step?mpps[u]:mpp[u]).size();i++)
    {
        int v = (step?mpps[u]:mpp[u])[i];
        if(!vis[v])
            dfs(v,step);
    }
    ord[cnt++] = u;
}
void dfs2(int u){
    vis[u] = 1;
    color[u] = cnt;
    for(int i=0;i<mppr[u].size();i++)
    {
        int v = mppr[u][i];
        if(!vis[v])
            dfs2(v);
    }
}
void adde_SCC(int u,int v){
    mpp[u].pb(v);
    mppr[v].pb(u);
}
int SCC(int N){
    mem(vis,0);
    cnt = 1;
    rep(i,0,N)
        if(!vis[i])
            dfs(i,0);
    mem(vis,0);
    cnt = 1;
    red(i,N+1,1)
        if(!vis[ord[i]])
        {
            dfs2(ord[i]);
            cnt++;
        }
    return cnt-1;
}

void buildSCCG(int N){
    rep(i,0,N)
    {
        for(int j=0;j<mpp[i].size();j++)
        {
            int v = mpp[i][j];
            if(color[i]!=color[v])
                mpps[color[v]].pb(color[i]);
        }
        mppd[color[i]].pb(color[i^1]);
    }
}

void inAct(int u){
    vis[u] = 1;
    for(int i=0;i<mpps[u].size();i++)
    {
        int v = mpps[u][i];
        if(!vis[v])
            inAct(v);
    }
}
void doAct(int u){
    vis[u] = 1;
    act[u] = 1;
    for(int i=0;i<mppd[u].size();i++)
    {
        int v = mppd[u][i];
        if(!vis[v])
            inAct(v);
    }
}

bool twoSat(int N){
    int totColor = SCC(N);
    rep(i,0,N)
        if(color[i]==color[i^1])
            return false;
    buildSCCG(N);
    cnt = 1;
    mem(vis,0);
    rep(i,1,totColor)
        if(!vis[i])
            dfs(i,1);
    /*------according to question-------*/
    mem(vis,0);
    mem(act,0);
    red(i,totColor,1)
        if(!vis[ord[i]])
            doAct(ord[i]);

    return true;
}
/*
两者（x, y) 不能同时取
adde_SCC(x, y^1);
adde_SCC(y, x^1);

两者 (x, y) 不能同时不取
adde_SCC(x^1, y);
adde_SCC(y^1, x);

两者 (x, y) 要么都取，要么都不取
adde_SCC(x, y);
adde_SCC(y, x);
adde_SCC(x^1, y^1);
adde_SCC(y^1, x^1);

两者 (x, x^1) 必取 x
adde_SCC(x^1, x);
*/
int main(){
    int tot = f(n-1,1);
    bool succ = twoSat(tot);
    if(!succ)
    {
        puts("bad luck");
        continue;
    }

    rep(i,1,n-1)
    {
        if(act[color[f(i,0)]] == act[color[0]])
            printf("%dw%c",i,i==n-1?'\n':' ');
        else
            printf("%dh%c",i,i==n-1?'\n':' ');
    }
}