int vis[maxn];
vector<int> mpp[maxn];//vector<int> mpp;

void dfs(int u){
    //在没有邻居的信息前，do something
    vis[u] = 1;
    for(auto v:mpp[u])
    {
        //无差别对邻居 do something
        if(!vis[v])
            dfs(v);//只对没访问过的邻居 do something
    }
    //在有邻居的信息后, do something
}
int main(){
    mem(vis,0);
    loop(0,n)
        if(!vis[i])
            dfs(i);
}

int vis[maxn];
vector<int> mpp[maxn];//vector<int> mpp;

void bfs(int u){
    mem(vis,0);
    q.push(u);//还可以放其他点，这些点都有性质A
    int cur;
    while(!q.empty())
    {
        cur = q.front();
        q.pop();
        if(vis[cur])
            continue;   //注意
        if(A)           //如果满足性质A，就visit这个点, 不然不要管就行了，以后这个点满足A后还会入队的，有点像spfa()
        {
            for(auto v:mpp[cur])
            {
                q.push(v);    //无条件入队，哪怕visit过
                //do something, 比如对每个邻居更新一下距离，relax什么的，邻居被visit过也没事
            }
            vis[cur] = 1;//对邻居做完事情后，就visit，和dfs的顺序不一样
        }
        if(B)   //如果我们希望看到的B发生了，do something
        {

        }
    }
    //如果bfs结束，程序运行到这里，说明我们希望的B没有发生，do something
    return;
}










