typedef ll mytype;
const int NV=10005;
const int NE=10005*2;
int he[NV],ecnt;
int n,m;
struct edge
{
    int v,next;
    mytype l,cap;
} E[NE];

//¤@¦¸¹L¥[¨â±øÃä 
void init(){
    ecnt=0;
    memset(he,-1,sizeof(he));
}
void adde(int u,int v,mytype l,mytype c)
{
    E[ecnt].v=v;
    E[ecnt].l=l;
    E[ecnt].cap = c;
    E[ecnt].next=he[u];
    he[u]=ecnt++;
    E[ecnt].v=u;
    E[ecnt].l=-l;
    E[ecnt].cap=0;
    E[ecnt].next=he[v];
    he[v]=ecnt++;
}
int vis[NV];
int num[NV];
ll dis[NV];
int pre[NV];//NV-1¬Osource¡ANV-2¬Osink
ll res;
bool spfa(){
    int u;
    mem(pre,-1);
    deque<int> q;
    for(int i=0;i<NV;i++)
        dis[i] = INF;
    mem(vis,0);
    mem(num,0);
    dis[NV-1] = 0;
    q.pb(NV-1);
    vis[NV-1] = 1;
    while(q.size())
    {
        u = q.front();q.pop_front();
        vis[u] = 0;
        for (int i=he[u]; i!=-1; i=E[i].next)
        {
            int v = E[i].v;
            if(E[i].cap && dis[v]>dis[u]+E[i].l)
            {
                dis[v] = dis[u] + E[i].l;
                pre[v] = i;
                if(!vis[v] && num[v]<n && v!=NV-2)
                {
                    vis[v] = 1;
                    if(q.empty()||dis[v]>dis[q.front()])
                        q.pb(v);
                    else
                        q.push_front(v);
                    num[v]++;
                }
            }
        }
    }
    if(dis[NV-2]>=INF-1) return false;
    /* end() */
    int p,sum = INF;
    ll t = 0;
    for(u = NV-2;u!=NV-1;u=E[(p^1)].v){
        p = pre[u];
        sum = min(sum,E[p].cap);
    }
    for(u = NV-2;u!=NV-1;u=E[(p^1)].v){
        p = pre[u];
        E[p].cap -= sum;
        E[(p^1)].cap += sum;
    	t += sum*E[p].l;
    }
    // if(t > 0) return false; //视情况，负边就这个，正边就是t<0
    res += t;
    return true;
}

ll MCF(){
    res = 0;
    for(int i=0;i<ecnt;i+=2)
    {
        E[i].cap+=E[i^1].cap;
        E[i^1].cap = 0;
    }
    while(spfa());
    //µø¥G±¡ªpÀË¬d¬O§_²Å¦X±ø¥ó 
    //return: ³Ì¤Ö¶O¥Î 
    return res;
}
