#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <math.h>
#include <stdlib.h>
#include <cstring>
#include <stdio.h>
#include <algorithm>
#include <iomanip>
#include <vector>
#include <queue>
#include <unordered_set>
#include <sstream>

#define maxn 1000005
using namespace std;

class WordDictionary {
public:
    int next[10010][26],ed[10010];
    int root,L;
    bool ini=false;
    int newnode()
    {
        for(int i = 0; i < 26; i++)
            next[L][i] = -1;
        ed[L++] = 0;
        return L-1;
    }
    void init()
    {
        L = 0;
        root = newnode();
    }
    void insert(string buf)
    {
        int len = buf.length();
        int now = root;
        for(int i = 0; i < len; i++)
        {
            if(next[now][buf[i]-'a'] == -1)
                next[now][buf[i]-'a'] = newnode();
            now = next[now][buf[i]-'a'];
        }
        ed[now]++;
    }
    // Adds a word into the data structure.
    void addWord(string word) {
        if(ini==false)
        {
            init();
            ini=true;
        }
        insert(word);
    }

    // Returns if the word is in the data structure. A word could
    // contain the dot character '.' to represent any one letter.
    bool work(string word,int rt,int now){
        if(now==word.length()-1)
        {
            if(word[now]=='.')
            {
                for(int i=0;i<26;i++)
                {
                    if(next[rt][i]!=-1)
                        if(ed[next[rt][i]]>0)
                            return true;
                }
                return false;
            }

            if(next[rt][word[now]-'a']==-1)
                return false;
            if(ed[next[rt][word[now]-'a']]>0)
                return true;
            else
                return false;
        }
        if(word[now]=='.')
        {
            for(int i=0;i<26;i++)
            {
                if(next[rt][i]!=-1)
                    if(work(word,next[rt][i],now+1))
                        return true;
            }
            return false;
        }
        if(next[rt][word[now]-'a']==-1)
            return false;
        else
            return work(word,next[rt][word[now]-'a'],now+1);

    }
    bool search(string word) {
        return work(word,root,0);
    }
};
int main() {
//    std::ios::sync_with_stdio(false);
//    freopen("/Users/huangqingwei/Documents/C++ workspace/codeforces/input.txt", "r",stdin);
    WordDictionary a;
    a.addWord("bad");
    a.addWord("dad");
    a.addWord("mad");
    cout<<a.search("pad")<<endl;
    cout<<a.search("bad")<<endl;
    cout<<a.search(".ad")<<endl;
    cout<<a.search("b..")<<endl;

    return 0;

}