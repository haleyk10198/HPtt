//有环也没关系的dfs topological sort, 为2-sat用
int vis[maxn];
int ord[maxn];
int cnt = 0;
vector<int> mpp[maxn];
void dfs(int u){
    vis[u] = 1;
    for(auto v:mpp[u])
        if(!vis[v])
            dfs(v);
    ord[u] = cnt++;
}
int main(){
    for(int i=0;i<n;i++)
        if(!vis[i])
            dfs(i);
}