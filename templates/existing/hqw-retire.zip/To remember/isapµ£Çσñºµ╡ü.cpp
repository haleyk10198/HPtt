const int max_n = 220;
const int max_m = 1005;
const int max_e = max_m * 2;
const int inf = 1e9;

int point[max_n], nxt[max_e], v[max_e], remain[max_e], tot;
int deep[max_n], num[max_n], cur[max_n], lastedge[max_n];//deep记录分层信息，num记录每一层的点数，lastedge记录前驱节点
bool vis[max_n];
int n, m;

inline void addedge(int x, int y, int cap) //处理边的信息，注意从0开始存
{
    tot++; nxt[tot] = point[x]; point[x] = tot; v[tot] = y; remain[tot] = cap;
    tot++; nxt[tot] = point[y]; point[y] = tot; v[tot] = x; remain[tot] = 0;
}

inline int addflow(int s, int t)
{
    int ans = inf, now = t;
    while (now != s) {
        ans = min(ans, remain[lastedge[now]]);
        now = v[lastedge[now] ^ 1];
    }
    now = t;
    while (now != s) {
        remain[lastedge[now]] -= ans;
        remain[lastedge[now] ^ 1] += ans;
        now = v[lastedge[now] ^ 1];//因为isap是从汇点扩展的
    }
    return ans;
}

inline void bfs(int t) {
    for (int i = 1; i <= n; i++)
        deep[i] = n;
    memset(vis, 0, sizeof(vis));
    queue<int> q;
    deep[t] = 0;
    q.push(t); vis[t] = true;
    while (!q.empty()) {
        int now = q.front(); q.pop();
        for (int tmp = point[now]; tmp != -1; tmp = nxt[tmp])
            if (!vis[v[tmp]] && remain[tmp ^ 1]) //remain[tmp^1]求逆向边
            {
                vis[v[tmp]] = true;
                deep[v[tmp]] = deep[now] + 1;
                q.push(v[tmp]);
            }
    }
}

inline int isap(int s, int t) {
    int ans = 0, now = s;
    bfs(t);
    for (int i = 1; i <= n; i++) num[deep[i]]++;
    for (int i = 1; i <= n; i++) cur[i] = point[i];//cur 当前弧优化，记录当前检查到哪一条边

    while (deep[s] < n) {
        if (now == t) {
            ans += addflow(s, t);
            now = s;
        }

        bool has_find = false;
        for (int tmp = cur[now]; tmp != -1; tmp = nxt[tmp]) {
            int u = v[tmp];
            if (deep[u] + 1 == deep[now] && remain[tmp]) {
                has_find = true;
                cur[now] = tmp;
                lastedge[u] = tmp;
                now = u;
                break;
            }
        }

        if (!has_find) {//没有找到增广路，对now当前点重新标号
            int minn = n - 1;
            for (int tmp = point[now]; tmp != -1; tmp = nxt[tmp])
                if (remain[tmp])
                    minn = min(minn, deep[v[tmp]]); //从所以相连节点中选取编号最小的
            if (!(--num[deep[now]])) break;//GAP优化，如果编号出现了断层，说明不能再增广，那么此时的答案即为最大流
            num[deep[now] = minn + 1]++;
            cur[now] = point[now];
            if (now != s)
                now = v[lastedge[now] ^ 1];
        }
    }
    return ans;
}
void init(){
    tot = -1;
    memset(point, -1, sizeof(point));
    memset(nxt, -1, sizeof(nxt));
}
int main(){
    init();
    addedge(x,y,w*10000+1);
    printf("%d\n",isap(src,sink));
}